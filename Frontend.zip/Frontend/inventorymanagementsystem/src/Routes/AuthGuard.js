import React from 'react';
import { Navigate } from 'react-router-dom';
import { jwtDecode } from 'jwt-decode';
 
const AuthGuard = ({ children, roles }) => {
    const token = localStorage.getItem('authToken');
 
    if (!token) {
        // Not logged in
        return <Navigate to="/login" replace />;
    }
 
    try {
        const decodedToken = jwtDecode(token);
        const userRoles = decodedToken?.roles?.map(role => role.authority);//Optional chaining
 
        // If roles are specified, check access
        if (roles && (!userRoles || !roles.some(role => userRoles.includes(role)))) {
            // Role mismatch
            return <Navigate to="/login" replace />;
        }
 
        // Access granted
        return children;
    } catch (error) {
        console.error("Error decoding token:", error);
        return <Navigate to="/login" replace />;
    }
};
 
export default AuthGuard;