import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import AuthGuard from '../Routes/AuthGuard';
 
import LoginPage from '../Components/Auth/LoginPage';
import SignupPage from '../Components/Auth/SignupPage';
import WelcomePage from '../Components/Auth/WelcomePage';
 
import AdminDashboard from '../Components/Admin/AdminDashboard';
import HomePage from '../Components/Admin/AdminHomePage';
import InventoryListPage from '../Components/Product/InventoryListPage';
import AddNewProductPage from '../Components/Product/AddNewProductPage';
import EditProductPage from '../Components/Product/EditProductPage';
import StockListPage from '../Components/Stocks/StockListPage';
import StockUpdatePage from '../Components/Stocks/StockUpdatePage';
import SupplierListPage from '../Components/Suppliers/SupplierListPage';
import AddSupplierPage from '../Components/Suppliers/AddSupplierPage';
import UpdateSupplierPage from '../Components/Suppliers/UpdateSupplierPage';
import ReportListPage from '../Components/Reports/ReportListPage';
import AddReportPage from '../Components/Reports/AddReportPage';
import UpdateReportPage from '../Components/Reports/UpdateReportPage';
import OrderListPage from '../Components/Orders/OrderListPage';
import UpdateOrderPage from '../Components/Orders/UpdateOrderPage';
import CustomerListPage from '../Components/Customers/CustomerListPage';
import NotificationListPage from '../Components/Notifications/NotificationListPage';
import AddAdmin from '../Components/Admin/AddAdmin';
import AdminProfile from '../Components/Admin/AdminProfilePage';
 
import CustomerDashboard from '../Components/Customers/CustomerDashboard';
import CustomerOverviewPage from '../Components/Customers/CustomerOverviewPage';
import CustomerProfile from '../Components/Customers/CustomerProfile';
import CustomerOrdersPage from '../Components/Customers/CustomersOrdersPage';
import ProductsPage from '../Components/Product/ProductsPage';
 
const AppRoutes = () => {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/login" element={
                    <div className="auth-page">
                        <LoginPage />
                    </div>
                } />
                <Route path="/signup" element={
                    <div className="auth-page">
                        <SignupPage />
                    </div>
                } />
                <Route path="/" element={<WelcomePage />} />
 
                {/* Admin Routes */}
                <Route path="/admin" element={
                    <AuthGuard roles={['ROLE_ADMIN']}>
                        <AdminDashboard />
                    </AuthGuard>
                }>
                    <Route index element={<Navigate to="/admin/home" />} />
                    <Route path="home" element={<HomePage />} />
                    <Route path="inventory" element={
                        <div className="admin-page">
                            <InventoryListPage />
                        </div>
                    } />
                    <Route path="inventory/add" element={
                        <div className="admin-page">
                            <AddNewProductPage />
                        </div>
                    } />
                    <Route path="inventory/edit" element={
                        <div className="admin-page">
                            <EditProductPage />
                        </div>
                    } />
                    <Route path="inventory/edit/:id" element={
                        <div className="admin-page">
                            <EditProductPage />
                        </div>
                    } />
                    <Route path="stocks" element={
                        <div className="admin-page">
                            <StockListPage />
                        </div>
                    } />
                    <Route path="stocks/edit/:productId" element={
                        <div className="admin-page">
                            <StockUpdatePage />
                        </div>
                    } />
                    <Route path="/admin/suppliers" element={
                        <div className="admin-page">
                            <SupplierListPage />
                        </div>
                    } />
                    <Route path="/admin/suppliers/add" element={
                        <div className="admin-page">
                            <AddSupplierPage />
                        </div>
                    } />
                    <Route path="/admin/suppliers/edit/:supplierId" element={
                        <div className="admin-page">
                            <UpdateSupplierPage />
                        </div>
                    } />
                    <Route path="reports" element={
                        <div className="admin-page">
                            <ReportListPage />
                        </div>
                    } />
                    <Route path="reports/add" element={
                        <div className="admin-page">
                            <AddReportPage />
                        </div>
                    } />
                    <Route path="reports/edit/:reportId" element={
                        <div className="admin-page">
                            <UpdateReportPage />
                        </div>
                    } />
                    <Route path="/admin/orders" element={
                        <div className="admin-page">
                            <OrderListPage />
                        </div>
                    } />
                    <Route path="/admin/orders/edit/:orderId" element={
                        <div className="admin-page">
                            <UpdateOrderPage />
                        </div>
                    } />
                    <Route path="/admin/users" element={
                        <div className="admin-page">
                            <CustomerListPage />
                        </div>
                    } />
                    <Route path="/admin/notifications" element={
                        <div className="admin-page">
                            <NotificationListPage />
                        </div>
                    } />
                    <Route path="addAdmin" element={
                        <div className="admin-page">
                            <AddAdmin />
                        </div>
                    } />
                </Route>
 
                <Route path="/adminProfile" element={
                    <AuthGuard roles={['ROLE_ADMIN']}>
                        <div className="admin-page">
                            <AdminProfile />
                        </div>
                    </AuthGuard>
                } />
 
                {/* Customer Routes */}
                <Route path="/customer" element={
                    <AuthGuard roles={['ROLE_CUSTOMER']}>
                        <CustomerDashboard />
                    </AuthGuard>
                }>
                    <Route index element={<CustomerOverviewPage />} />
                    <Route path="products" element={<ProductsPage />} />
                    <Route path="/customer/profile" element={<CustomerProfile />} />
                    <Route path='orders' element={<CustomerOrdersPage />} />
                </Route>
            </Routes>
        </BrowserRouter>
    );
};
 
export default AppRoutes;
 