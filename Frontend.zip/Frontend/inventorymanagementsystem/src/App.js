// App.js
import React from 'react';
import AppRoutes from './Routes/AppRoutes';
// import './App.css'; // Assuming App.css is in src

function App() {
  return (
    <div className="app-container">
    <div className="right-section">
      <AppRoutes />
    </div>
  </div>
  );
}

export default App;