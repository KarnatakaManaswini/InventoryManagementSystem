import React, { useState, useEffect } from 'react';
import { Link,useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/InventoryListPage.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBoxOpen, faTrash, faEdit, faPlus, faSearch } from '@fortawesome/free-solid-svg-icons';

const InventoryListPage = () => {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredProducts, setFilteredProducts] = useState([]);
    const token = localStorage.getItem('authToken');

    useEffect(() => {
        const fetchProducts = async () => {
            setLoading(true);
            try {
                const response = await axios.get('http://localhost:8080/api/products/getAll', {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setProducts(response.data);
                setLoading(false);
            } catch (error) {
                setError('Failed to fetch products.');
                setLoading(false);
                console.error('Error fetching products:', error);
            }
        };

        fetchProducts();
    }, [navigate,token]);

    useEffect(() => {
        const filterProducts = () => {
            const lowerCaseSearchTerm = searchTerm.toLowerCase();
            const results = products.filter(product =>
                product.name.toLowerCase().includes(lowerCaseSearchTerm) ||
                product.description.toLowerCase().includes(lowerCaseSearchTerm) ||
                String(product.productId).includes(lowerCaseSearchTerm) ||
                String(product.price).includes(lowerCaseSearchTerm) ||
                String(product.stockLevel).includes(lowerCaseSearchTerm)
            );
            setFilteredProducts(results);
        };

        filterProducts();
    }, [searchTerm, products]);

    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value);
    };

    const handleDeleteProduct = async (productId) => {
        if (window.confirm('Are you sure you want to delete this product?')) {
            try {
                await axios.delete(`http://localhost:8080/api/products/deleteById/${productId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setProducts(products.filter((product) => product.productId !== productId));
                alert('Product deleted successfully.');
            } catch (error) {
                console.error('Error deleting product:', error);
                alert('Failed to delete product.');
            }
        }
    };

    if (loading) return <div>Loading products...</div>;
    if (error) return <div>Error: {error}</div>;

    return (
        <div className="inventory-list-container">
            <div className="inventory-list-header">
                <h2>Inventory List</h2>
                <div className="inventory-actions">
                    <div className="search-container">
                        <input
                            type="text"
                            className="search-input"
                            placeholder="Search products..."
                            value={searchTerm}
                            onChange={handleSearchChange}
                        />
                        <button className="search-button">
                            <FontAwesomeIcon icon={faSearch} />
                        </button>
                    </div>
                    <Link to="/admin/inventory/add" className="button addproduct-button">
                        <FontAwesomeIcon icon={faPlus} /> Add
                    </Link>
                </div>
            </div>
            <div className="product-table-container">
                {filteredProducts.length > 0 ? (
                    <table className="product-table">
                        <thead>
                            <tr>
                                <th>Product ID</th>
                                <th>Product Name</th>
                                <th>Description</th>
                                <th>Price</th>
                                <th>Stock Level</th>
                                <th className="actions-column">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredProducts.map(product => (
                                <tr key={product.productId}>
                                    <td>{product.productId}</td>
                                    <td>{product.name}</td>
                                    <td className="product-data-cell">{product.description}</td>
                                    <td>{product.price}</td>
                                    <td>{product.stockLevel}</td>
                                    <td className="actions-column">
                                        <button
                                            className="button action-button updateproduct-button"
                                            onClick={() => navigate(`/admin/inventory/edit/${product.productId}`)}
                                        >
                                            <FontAwesomeIcon icon={faEdit} /> Update
                                        </button>
                                        <button onClick={() => handleDeleteProduct(product.productId)} className="button action-button deleteproduct-button"><FontAwesomeIcon icon={faTrash} /> Delete</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div className="no-products-container"> {/* New container for better styling */}
                        <div className="no-products">
                            <FontAwesomeIcon icon={faBoxOpen} className="empty-icon" />
                            <p>{searchTerm ? 'No products found matching your search.' : 'No products in inventory yet. Click "Add New Product" to get started.'}</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default InventoryListPage;