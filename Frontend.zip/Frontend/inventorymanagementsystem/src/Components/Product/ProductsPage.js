import React, { useState, useEffect } from 'react';
import ProductCard from './ProductCard';
import '../../CSS/ProductsPage.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons';

const ProductsPage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredProducts, setFilteredProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const token = localStorage.getItem('authToken');
        const response = await fetch('http://localhost:8080/api/products/getAll', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });
        if (!response.ok) {
          throw new Error('Failed to fetch products');
        }
        const data = await response.json();
        setProducts(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  useEffect(() => {
    const filterProducts = () => {
      const lowerCaseSearchTerm = searchTerm.toLowerCase();
      const results = products.filter(product =>
        product.name.toLowerCase().includes(lowerCaseSearchTerm) ||
        product.description.toLowerCase().includes(lowerCaseSearchTerm)
      );
      setFilteredProducts(results);
    };

    filterProducts();
  }, [searchTerm, products]);

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  return (
    <div className="customers-products-page">
      <div className="inventory-search-header"> {/* Changed class name */}
        <h1 className="h1">Inventory List</h1>
        <div className="search-container">
          <input
            type="text"
            className="search-input"
            placeholder="Search products..."
            value={searchTerm}
            onChange={handleSearchChange}
          />
          <button className="search-button">
            <FontAwesomeIcon icon={faSearch} />
          </button>
        </div>
      </div>
      <div className="customers-products-grid">
        {filteredProducts.map(product => (
          <ProductCard key={product.productId} product={product} />
        ))}
      </div>
      {filteredProducts.length === 0 && searchTerm && !loading && !error && (
        <div className="no-products-found">No products found matching your search.</div>
      )}
      {loading && <div className="customers-loading">Loading products...</div>}
      {error && <div className="customers-error">Error: {error}</div>}
      {products.length === 0 && !loading && !error && !searchTerm && (
        <div className="no-products-found">No products available.</div>
      )}
    </div>
  );
};

export default ProductsPage;