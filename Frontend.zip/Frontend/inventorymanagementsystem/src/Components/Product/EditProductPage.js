import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/EditProductPage.css'; // Ensure correct path to the CSS

const EditProductPage = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [price, setPrice] = useState('');
    const [stockLevel, setStockLevel] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const token = localStorage.getItem('authToken');

    useEffect(() => {
        const fetchProduct = async () => {
            try {
                const response = await axios.get(`http://localhost:8080/api/products/getById/${id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                const product = response.data;
                setName(product.name);
                setDescription(product.description);
                setPrice(product.price);
                setStockLevel(product.stockLevel);
                setLoading(false);
            } catch (error) {
                setError('Failed to fetch product details.');
                setLoading(false);
                console.error('Error fetching product:', error);
            }
        };

        fetchProduct();
    }, [id, token]);

    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            await axios.put(
                `http://localhost:8080/api/products/update/${id}`,
                { name, description, price, stockLevel },
                { headers: { Authorization: `Bearer ${token}` } }
            );
            alert('Product updated successfully!');
            navigate('/admin/inventory');
        } catch (error) {
            setError('Failed to update product.');
            console.error('Error updating product:', error);
        }
    };

    if (loading) return <p>Loading product details...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div className="add-new-product-wrapper"> {/* Using wrapper for consistency */}
            <div className="edit-product-container"> {/* Using the specific container class */}
                <h2 className="edit-product-container h2">Update Product</h2> {/* Using the specific header style */}
                <form className="edit-product-form" onSubmit={handleSubmit}> {/* Using the specific form class */}
                    <div className="form-group">
                        <label htmlFor="name">Product Name:</label>
                        <input
                            type="text"
                            id="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="description">Description:</label>
                        <textarea
                            id="description"
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="price">Price:</label>
                        <input
                            type="number"
                            id="price"
                            value={price}
                            onChange={(e) => setPrice(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="stockLevel">Stock Level:</label>
                        <input
                            type="number"
                            id="stockLevel"
                            value={stockLevel}
                            onChange={(e) => setStockLevel(e.target.value)}
                            required
                        />
                    </div>
                    <div className="button-group"> {/* Using the button group class */}
                        <button
                            type="button"
                            className="button productsecondary-button"
                            onClick={() => navigate('/admin/inventory')}
                        >
                            Cancel
                        </button>
                        <button type="submit" className="button productprimary-button">
                            Update Product
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default EditProductPage;