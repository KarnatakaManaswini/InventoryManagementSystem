import React, { useState } from 'react';
import { useNavigate,Link } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/AddNewProductPage.css'; // Assuming CSS is in src/components/css

const AddNewProductPage = () => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [price, setPrice] = useState('');
    const [stockLevel, setStockLevel] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const token = localStorage.getItem('authToken');

    const handleSubmit = async (event) => {
        event.preventDefault();
        setError('');

        try {
            const response = await axios.post(
                'http://localhost:8080/api/products/add',
                { name, description, price: parseFloat(price), stockLevel: parseInt(stockLevel) },
                { headers: { Authorization: `Bearer ${token}` } }
            );
            if (response.status === 201) {
                navigate('/admin/inventory');
            } else {
                setError('Failed to add product.');
            }
        } catch (error) {
            setError('Failed to add product.');
            console.error('Error adding product:', error);
        }
    };

    return (
        <div className="add-new-product-wrapper">
            <div className="add-new-product-container">
                <h2 className="add-new-product-container h2">Add New Product</h2>
                {error && <p className="error-message">{error}</p>}
                <form className="add-product-form" onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="name">Name:</label>
                        <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required />
                    </div>
                    <div className="form-group">
                        <label htmlFor="description">Description:</label>
                        <textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} />
                    </div>
                    <div className="form-group">
                        <label htmlFor="price">Price:</label>
                        <input type="number" id="price" value={price} onChange={(e) => setPrice(e.target.value)} required />
                    </div>
                    <div className="form-group">
                        <label htmlFor="stockLevel">Stock Level:</label>
                        <input type="number" id="stockLevel" value={stockLevel} onChange={(e) => setStockLevel(e.target.value)} required />
                    </div>
                    <div className="button-group">
                        <Link to="/admin/inventory" className="button secondary-button">Cancel</Link>
                        <button type="submit" className="button primary-button">Add Product</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddNewProductPage;