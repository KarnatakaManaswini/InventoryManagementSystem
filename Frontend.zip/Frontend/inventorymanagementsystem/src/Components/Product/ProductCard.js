import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
const ProductCard = ({ product }) => {
  const [quantity, setQuantity] = useState(1);
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
 
  const handlePlaceOrder = async () => {
    setIsLoading(true);
    setMessage('');
 
    try {
      const token = localStorage.getItem('authToken');
      const email = JSON.parse(atob(token.split('.')[1]))?.sub;
 
      if (!token || !email) {
        navigate('/login');
        return;
      }
 
      const formData = new URLSearchParams();
      formData.append("email", email);
      formData.append("productId", product.productId);
      formData.append("quantity", quantity);
 
      const response = await fetch('http://localhost:8080/api/orders/placeOrder', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': `Bearer ${token}`
        },
        body: formData.toString()
      });
 
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || 'Failed to place order');
      }
 
      setMessage('Order placed successfully!');
      setQuantity(1); // Reset after success
    } catch (error) {
      console.error(error);
      setMessage(error.message);
    } finally {
      setIsLoading(false);
    }
  };
 
  return (
    <div className="customers-product-card">
 
      <div className="customers-product-details">
        <h3>{product.name}</h3>
        <p className="customers-price">₹{product.price.toFixed(2)}</p>
        <p className="customers-stock">Available: {product.stockLevel}</p>
        <p className="customers-description">{product.description}</p>
 
        <div className="customers-quantity-control">
          <button
            onClick={() => setQuantity(q => Math.max(1, q - 1))}
            disabled={quantity <= 1}
          >-</button>
 
          <input
            type="number"
            min="1"
            max={product.stockLevel}
            value={quantity}
            onChange={(e) => {
              const value = Math.max(1, Math.min(product.stockLevel, parseInt(e.target.value) || 1));
              setQuantity(value);
            }}
          />
 
          <button
            onClick={() => setQuantity(q => Math.min(product.stockLevel, q + 1))}
            disabled={quantity >= product.stockLevel}
          >+</button>
        </div>
 
        <button
          onClick={handlePlaceOrder}
          disabled={isLoading || product.stockLevel < 1}
          className="customers-order-button"
        >
          {isLoading ? 'Processing...' : 'Order Now'}
        </button>
 
        {message && (
          <div className={`customers-message ${message.includes('success') ? 'success' : 'error'}`}>
            {message}
          </div>
        )}
      </div>
    </div>
  );
};
 
export default ProductCard;
 