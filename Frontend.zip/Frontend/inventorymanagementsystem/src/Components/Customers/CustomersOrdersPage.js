import React, { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import '../../CSS/CustomersOrdersPage.css';
 
const CustomerOrdersPage = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [refresh, setRefresh] = useState(false);
 
  const token = localStorage.getItem('authToken');
 
  const formatPrice = (value) =>
    new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
    }).format(value);
 
  // Memoize fetchOrders using useCallback
  const fetchOrders = useCallback(async () => {
    try {
      const profileRes = await axios.get(
        `http://localhost:8080/api/customers/my-profile`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const customerId = profileRes.data.customerId;
 
      const orderRes = await axios.get(
        `http://localhost:8080/api/orders/customer/${customerId}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
 
      const filteredOrders = orderRes.data.filter(
        (order) => order.status !== 'Cancelled'
      );
 
      if (filteredOrders.length === 0) {
        setOrders([]);
        setLoading(false);
        return;
      }
 
      const ordersWithDetails = await Promise.all(
        filteredOrders.map(async (order) => {
          const productRes = await axios.get(
            `http://localhost:8080/api/products/getById/${order.productId}`,
            { headers: { Authorization: `Bearer ${token}` } }
          );
          const product = productRes.data;
          return {
            ...order,
            productName: product.name,
            productPrice: product.price,
            totalPrice: product.price * order.quantity,
          };
        })
      );
 
      setOrders(ordersWithDetails);
    } catch (err) {
      if (err.response && err.response.status === 404) {
        setOrders([]); // No orders but not a crash
      } else {
        console.error(err);
        setErrorMsg('Something went wrong while loading your orders.');
      }
    } finally {
      setLoading(false);
    }
  }, [token]); // Add token as a dependency
 
  useEffect(() => {
    fetchOrders();
  }, [fetchOrders, refresh]); // Add fetchOrders and refresh as dependencies
 
  const handleCancelOrder = async (orderId) => {
    try {
      await axios.delete(`http://localhost:8080/api/orders/deleteById/${orderId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      alert(`Order cancelled successfully`);
      setRefresh(!refresh); // Trigger refresh
    } catch (err) {
      console.error(err);
      alert(`Failed to cancel order #${orderId}`);
    }
  };
 
  return (
    <div className="orders-container">
      <h2 className="orders-heading">Your Orders</h2>
 
      {loading && <div className="loader">Loading...</div>}
      {errorMsg && <div className="error-msg">{errorMsg}</div>}
      {!loading && orders.length === 0 && (
        <p className="no-orders">No active orders found.</p>
      )}
 
      {!loading && orders.length > 0 && (
        <table className="orders-table">
          <thead>
            <tr>
              <th>Product</th>
              <th>Quantity</th>
              <th>Date</th>
              <th>Status</th>
              <th>Unit Price</th>
              <th>Total Price</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.orderId}>
                <td>{order.productName}</td>
                <td>{order.quantity}</td>
                <td>{order.orderdate}</td>
                <td>{order.status}</td>
                <td>{formatPrice(order.productPrice)}</td>
                <td>{formatPrice(order.totalPrice)}</td>
                <td>
                  {order.status === 'Pending' ? (
                    <button
                      className="cancel-btn"
                      onClick={() => handleCancelOrder(order.orderId)}
                    >
                      Cancel
                    </button>
                  ) : (
                    <span>—</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};
 
export default CustomerOrdersPage;