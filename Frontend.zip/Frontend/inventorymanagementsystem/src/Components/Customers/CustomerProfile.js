import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../../CSS/CustomerProfile.css';
 
const CustomerProfile = () => {
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [successMessage, setSuccessMessage] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phNo: ''
  });
 
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const token = localStorage.getItem('authToken');
        if (!token) {
          navigate('/login');
          return;
        }
 
        const response = await fetch('http://localhost:8080/api/customers/my-profile', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
 
        if (!response.ok) {
          throw new Error(response.status === 401 ? 'Session expired' : 'Failed to load profile');
        }
 
        const profileData = await response.json();
        setProfile(profileData);
        setFormData({
          name: profileData.name,
          email: profileData.email,
          phNo: profileData.phNo
        });
      } catch (err) {
        setError(err.message);
        if (err.message.includes('Session expired')) {
          localStorage.removeItem('authToken');
          navigate('/login');
        }
      } finally {
        setLoading(false);
      }
    };
 
    fetchProfile();
  }, [navigate]);
 
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);
 
    try {
      const token = localStorage.getItem('authToken');
      const response = await fetch('http://localhost:8080/api/customers/update-profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          name: formData.name,
          phNo: formData.phNo
        })
      });
 
      // Handle non-JSON responses
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        const text = await response.text();
        if (response.ok) {
          // Assume success if status is 2xx but response isn't JSON
          setSuccessMessage('Profile updated successfully!');
          setIsEditing(false);
          // Update local state optimistically
          setProfile(prev => ({
            ...prev,
            name: formData.name,
            phNo: formData.phNo
          }));
          // Update local storage if needed
          const user = JSON.parse(localStorage.getItem('user'));
          if (user && user.name !== formData.name) {
            localStorage.setItem('user', JSON.stringify({
              ...user,
              name: formData.name
            }));
          }
          return;
        } else {
          throw new Error(text || 'Failed to update profile');
        }
      }
 
      // Handle JSON responses
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || 'Failed to update profile');
      }
 
      setProfile(data);
      setSuccessMessage('Profile updated successfully!');
      setIsEditing(false);
     
      // Update local storage if name changed
      const user = JSON.parse(localStorage.getItem('user'));
      if (user && user.name !== data.name) {
        localStorage.setItem('user', JSON.stringify({
          ...user,
          name: data.name
        }));
      }
    } catch (err) {
      setError(err.message || 'An error occurred while updating the profile.');
    }
  };
 
  const handleCancel = () => {
    setIsEditing(false);
    if (profile) {
      setFormData({
        name: profile.name,
        email: profile.email,
        phNo: profile.phNo
      });
    }
    setError(null);
    setSuccessMessage(null);
  };
 
  if (loading) {
    return (
      <div className="profile-container">
        <div className="loading-spinner"></div>
        <p>Loading your profile...</p>
      </div>
    );
  }
 
  if (error) {
    return (
      <div className="profile-container">
        <div className="error-message">
          <span className="error-icon">⚠️</span>
          <p>{error}</p>
          <button onClick={() => navigate('/customer')} className="btn-primary">
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }
 
  if (!profile) {
    return (
      <div className="profile-container">
        <div className="no-profile">
          <p>No profile data available</p>
          <button onClick={() => navigate('/customer')} className="btn-primary">
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }
 
  return (
    <div className="profile-container">
      <div className="profile-header">
        <h2>My Profile</h2>
        {!isEditing && (
          <button
            onClick={() => setIsEditing(true)}
            className="btn-edit"
          >
            Edit Profile
          </button>
        )}
      </div>
 
      {successMessage && (
        <div className="success-message">
          <span className="success-icon">✓</span>
          <p>{successMessage}</p>
        </div>
      )}
 
      {!isEditing ? (
        <div className="profile-details">
          <div className="detail-row">
            <span className="detail-label">Name:</span>
            <span className="detail-value">{profile.name}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Email:</span>
            <span className="detail-value">{profile.email}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Phone:</span>
            <span className="detail-value">{profile.phNo || 'Not provided'}</span>
          </div>
        </div>
      ) : (
        <form className="profile-form" onSubmit={handleSubmit}>
          {error && <div className="form-error">{error}</div>}
         
          <div className="form-group">
            <label htmlFor="name">Full Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              required
              minLength="2"
            />
          </div>
 
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              disabled
              className="disabled-field"
            />
          </div>
 
          <div className="form-group">
            <label htmlFor="phNo">Phone Number</label>
            <input
              type="tel"
              id="phNo"
              name="phNo"
              value={formData.phNo}
              onChange={handleInputChange}
              pattern="[0-9]{10}"
              title="Please enter a 10-digit phone number"
            />
          </div>
 
          <div className="form-actions">
            <button type="submit" className="btn-save">
              Save Changes
            </button>
            <button
              type="button"
              className="btn-cancel"
              onClick={handleCancel}
            >
              Cancel
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
 
export default CustomerProfile;