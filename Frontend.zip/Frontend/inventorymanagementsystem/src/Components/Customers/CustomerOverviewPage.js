import React from 'react';
import '../../CSS/CustomerOverviewPage.css'; // Create this CSS file for styling
 
const CustomerOverviewPage = () => {
  return (
    <div className="customer-overview-container">
    <h2 className="customer-welcome-text">Welcome to Inventory!</h2> {/* Welcome text */}
    <div className="logo"></div> {/* Logo image */}
  </div>
  );
};
 
export default CustomerOverviewPage;
 