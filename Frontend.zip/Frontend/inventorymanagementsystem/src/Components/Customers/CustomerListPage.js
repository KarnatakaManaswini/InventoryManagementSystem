import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../../CSS/CustomerListPage.css'; // Keep its own CSS for specific styling
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faSearch } from '@fortawesome/free-solid-svg-icons';

const CustomerListPage = () => {
    const [customers, setCustomers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredCustomers, setFilteredCustomers] = useState([]);

    useEffect(() => {
        const fetchCustomers = async () => {
            setLoading(true);
            try {
                const token = localStorage.getItem('authToken');
                const response = await axios.get('http://localhost:8080/api/customers/getAllCustomers', {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setCustomers(response.data);
                setLoading(false);
            } catch (error) {
                setError('Failed to fetch customers.');
                setLoading(false);
            }
        };

        fetchCustomers();
    }, []);

    useEffect(() => {
        const filterCustomers = () => {
            const lowerCaseSearchTerm = searchTerm.toLowerCase();
            const results = customers.filter(customer =>
                customer.name.toLowerCase().includes(lowerCaseSearchTerm) ||
                customer.email.toLowerCase().includes(lowerCaseSearchTerm) ||
                String(customer.customerId).includes(lowerCaseSearchTerm) ||
                String(customer.phNo).includes(lowerCaseSearchTerm)
            );
            setFilteredCustomers(results);
        };

        filterCustomers();
    }, [searchTerm, customers]);

    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value);
    };

    if (loading) return <div className="loading-container">Loading customers...</div>;
    if (error) return <div className="error-container">Error: {error}</div>;

    return (
        <div className="customer-list-container"> {/* Keep its own container */}
            <div className="customer-list-header"> {/* Using customer-specific header style */}
                <h2>Customer List</h2>
                <div className="search-container"> {/* Using search container from ReportListPage (it's generic) */}
                    <input
                        type="text"
                        className="search-input"
                        placeholder="Search customers..."
                        value={searchTerm}
                        onChange={handleSearchChange}
                    />
                    <button className="search-button">
                        <FontAwesomeIcon icon={faSearch} />
                    </button>
                </div>
            </div>
            <div className="customer-table-container"> {/* Using customer-specific table container */}
                {filteredCustomers.length > 0 ? (
                    <table className="customer-table"> {/* Keep its own table style */}
                        <thead>
                            <tr>
                                <th>Customer ID</th>
                                <th>Name</th>
                                <th>Phone Number</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredCustomers.map(customer => (
                                <tr key={customer.customerId}>
                                    <td>{customer.customerId}</td>
                                    <td>{customer.name}</td>
                                    <td>{customer.phNo}</td>
                                    <td>{customer.email}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div className="no-customers-container"> {/* Using customer-specific no-data container */}
                        <div className="no-customers"> {/* Using customer-specific no-data div */}
                            <FontAwesomeIcon icon={faUser} className="empty-icon" />
                            <p>{searchTerm ? 'No customers found matching your search.' : 'No customers available.'}</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default CustomerListPage;