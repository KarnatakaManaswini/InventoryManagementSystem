import React from 'react';
import { Link, useNavigate, Outlet } from 'react-router-dom';
import '../../CSS/CustomerDashboard.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignOutAlt, faWarehouse } from '@fortawesome/free-solid-svg-icons';

const CustomerDashboard = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem('authToken');
        navigate('/login');
    };

    return (
        <div className="customer-dashboard-container">
            <div className="customer-dashboard-wrapper">
                <div className="customer-dashboard-title-container">
                    <Link to="/customer" className="customer-ims-link">
                        <FontAwesomeIcon icon={faWarehouse} className="customer-ims-icon" />
                        <span className="customer-ims-text">IMS</span>
                    </Link>
                </div>

                <div className="customer-nav-links-container">
                    <nav className="customer-main-nav">
                        <Link to="/customer/products" className="customer-nav-item">
                            <span className="customer-nav-text">Products</span>
                        </Link>
                        <Link to="/customer/orders" className="customer-nav-item">
                            <span className="customer-nav-text">Orders</span>
                        </Link>
                        <Link to="/customer/profile" className="customer-nav-item">
                            <span className="customer-nav-text">Profile</span>
                        </Link>
                    </nav>
                </div>

                <div className="customer-cart-logout-container">
                    <button className="customer-logout-button" onClick={handleLogout}>
                        <FontAwesomeIcon icon={faSignOutAlt} className="customer-nav-icon" />
                    </button>
                </div>
            </div>

            <main className="customer-main-content">
                <div className="customer-content-body">
                    <Outlet />
                </div>
            </main>
        </div>
    );
};

export default CustomerDashboard;
