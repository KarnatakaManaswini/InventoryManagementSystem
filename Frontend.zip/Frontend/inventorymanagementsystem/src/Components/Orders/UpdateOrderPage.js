import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/UpdateOrderPage.css'; // Ensure correct path to the CSS

const UpdateOrderPage = () => {
    const { orderId } = useParams();
    const [status, setStatus] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchOrder = async () => {
            setLoading(true);
            try {
                const token = localStorage.getItem('authToken'); // Retrieve token from localStorage
                if (!token) {
                    navigate('/login'); // Redirect to login if token is missing
                    return;
                }
                const { data: order } = await axios.get(`http://localhost:8080/api/orders/getOrderById/${orderId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`, // Add Authorization header
                    },
                });
                setStatus(order.status);
                setLoading(false);
            } catch (error) {
                setError('Failed to fetch order details.');
                console.error('Error fetching order:', error);
                setLoading(false);
            }
        };

        fetchOrder();
    }, [orderId, navigate]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('authToken'); // Retrieve token from localStorage
            await axios.put(
                `http://localhost:8080/api/orders/updateStatus/${orderId}`,
                null,
                {
                    params: { status },
                    headers: {
                        Authorization: `Bearer ${token}`, // Add Authorization header
                    },
                }
            );
            alert('Order status updated successfully!');
            navigate('/admin/orders');
        } catch (error) {
            setError('Failed to update order status.');
            console.error('Error updating order status:', error);
        }
    };

    if (loading) return <div className="loading-container">Loading order details...</div>;
    if (error) return <div className="error-container">Error: {error}</div>;

    return (
        <div className="update-order-wrapper">
        <div className="update-order-container"> {/* Using the same container as UpdateStockPage */}
            <h2 className="update-order-container h2">Update Order Status</h2> {/* Using the same header as UpdateStockPage */}
            <form className="update-order-form" onSubmit={handleSubmit}> {/* Using the same form class as UpdateStockPage */}
                {error && <p className="error-message">{error}</p>}
                <div className="form-group">
                    <label htmlFor="status"><span>Status:</span>
                    </label>
                    <select
                        id="status"
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                        required
                    >
                        <option value="">Select Status</option>
                        <option value="Pending">Pending</option>
                        <option value="Shipped">Shipped</option>
                        <option value="Delivered">Delivered</option>
                    </select>
                </div>
                <div className="button-container"> {/* Using the same button container as UpdateStockPage */}
                    <button
                        type="button"
                        className="button secondaryorder-button" 
                        onClick={() => navigate('/admin/orders')}
                    >
                        Cancel
                    </button>
                    <button type="submit" className="button primaryorder-button"> {/* Using the same primary button style as UpdateStockPage */}
                        Update Status
                    </button>
                </div>
            </form>
        </div>
       </div > 
    );
};

export default UpdateOrderPage;