import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/OrderListPage.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit } from '@fortawesome/free-solid-svg-icons';

const OrderListPage = () => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchOrders = async () => {
            setLoading(true);
            try {
                const token = localStorage.getItem('authToken'); // Retrieve token from localStorage
                const response = await axios.get('http://localhost:8080/api/orders/getAllOrders', {
                    headers: {
                        Authorization: `Bearer ${token}`, // Add Authorization header
                    },
                });
                setOrders(response.data);
                setLoading(false);
            } catch (error) {
                setError('Failed to fetch orders.');
                setLoading(false);
                console.error('Error fetching orders:', error);
            }
        };

        fetchOrders();
    }, [navigate]);

    if (loading) return <p>Loading orders...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div className="order-list-container"> {/* Updated class name */}
            <div className="order-list-header"> {/* Updated class name */}
                <h2 className="order-list-header h2">Order List</h2>
            </div>
            <div className="order-table-container"> {/* Updated class name for the table container */}
                {orders.length > 0 ? (
                    <table className="order-table"> {/* Assuming you want to keep this class for the table itself */}
                        <thead>
                            <tr>
                                <th>Product ID</th>
                                <th>Customer ID</th>
                                <th>Quantity</th>
                                <th>Order Date</th>
                                <th>Status</th>
                                <th className="actions-column">Actions</th> {/* Assuming you want to keep this */}
                            </tr>
                        </thead>
                        <tbody>
                            {orders.map((order) => (
                                <tr key={order.orderId}>
                                    <td>{order.productId}</td>
                                    <td>{order.customerId}</td>
                                    <td>{order.quantity}</td>
                                    <td>{order.orderdate}</td>
                                    <td>{order.status}</td>
                                    <td className="actions-column"> {/* Assuming you want to keep this */}
                                        <button
                                            className="button action-button updatestatus-button" 
                                            onClick={() => navigate(`/admin/orders/edit/${order.orderId}`)}
                                        >
                                            <FontAwesomeIcon icon={faEdit} /> Update Status
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div className="no-orders-container"> {/* Updated class name for no orders container */}
                        <p className="no-orders">No orders available.</p> {/* Added class name for no orders text */}
                    </div>
                )}
            </div>
        </div>
    );
};

export default OrderListPage;