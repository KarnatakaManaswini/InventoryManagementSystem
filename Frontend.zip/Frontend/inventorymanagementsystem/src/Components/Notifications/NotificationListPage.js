import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../../CSS/NotificationListPage.css';

const NotificationListPage = () => {
    const [notifications, setNotifications] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchNotifications = async () => {
            setLoading(true);
            try {
                const token = localStorage.getItem('authToken'); // Retrieve token from localStorage
                const response = await axios.get('http://localhost:8080/api/notifications/getAll', {
                    headers: {
                        Authorization: `Bearer ${token}`, // Add Authorization header
                    },
                });
                setNotifications(response.data);
                setLoading(false);

                
            } catch (error) {
                setError('Failed to fetch notifications.');
                setLoading(false);
                console.error('Error fetching notifications:', error);
            }
        };

        fetchNotifications();
    }, []);

    if (loading) return <p>Loading notifications...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div className="notification-list-container">
            <h2>Notifications</h2>
            {notifications.length > 0 ? (
                <table className="notification-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Message</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {notifications.map((notification) => (
                            <tr key={notification.id}>
                                <td>{notification.id}</td>
                                <td>{notification.message}</td>
                                <td>{new Date(notification.date).toLocaleString()}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <p>No notifications available.</p>
            )}
        </div>
    );
};

export default NotificationListPage;