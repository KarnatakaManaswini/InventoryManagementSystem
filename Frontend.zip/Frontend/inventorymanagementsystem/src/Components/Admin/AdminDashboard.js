import React from 'react';
import { Link, useNavigate, Outlet } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBoxOpen, faUsers, faShoppingCart, faChartBar, faSignOutAlt, faTruck, faWarehouse, faBell, faAdd, faUser } from '@fortawesome/free-solid-svg-icons';
import '../../CSS/AdminDashboard.css';
import '../../CSS/AdminTopRightNav.css'; // Import new CSS for top right nav
import { jwtDecode } from 'jwt-decode';

const AdminDashboard = () => {
    const navigate = useNavigate();
    const token = localStorage.getItem('authToken');
    let adminId = null;

    if (token) {
        try {
            console.log('Token:', token); // Debugging log
            const decodedToken = jwtDecode(token);
            console.log('Decoded Token:', decodedToken); // Debugging log
            adminId = decodedToken.customerId; // Use 'customerId' as per your JSON output
            console.log('Admin ID:', adminId); // Debugging log
        } catch (error) {
            console.error('Error decoding token:', error);
            navigate('/login'); // Redirect to login if token is invalid
        }
    } else {
        console.error('No token found. Redirecting to login.');
        navigate('/login'); // Redirect to login if no token is found
    }

    const handleLogout = () => {
        localStorage.removeItem('authToken');
        navigate('/login');
    };

    return (
        <div className="admin-dashboard-container">
            {/* Top Right Navigation */}
            <nav className="admin-nav-top-right">
                <ul>
                    <li>
                        <Link to="/admin/notifications" className="nav-link top-right-link notification-link">
                            <FontAwesomeIcon icon={faBell} className="nav-icon" />
                            {/* <span>Notifications</span> */}
                        </Link>
                    </li>
                    <li>
                        <Link to={token ? `/adminProfile` : '#'} className="nav-link top-right-link profile-link">
                            <FontAwesomeIcon icon={faUser} className="nav-icon" />
                            {/* <span>Profile</span> */}
                        </Link>
                    </li>
                    <li>
                        <button className="nav-link logout-button top-right-link logout-link" onClick={handleLogout}>
                            <FontAwesomeIcon icon={faSignOutAlt} className="nav-icon" />
                            {/* <span>Logout</span> */}
                        </button>
                    </li>
                </ul>
            </nav>

            {/* Sidebar */}
            <aside className="admin-sidebar">
                <div className="sidebar-header">
                    <Link to="/admin/home" className="ims-link">
                        <FontAwesomeIcon icon={faWarehouse} className="ims-icon" />
                        <span className="ims-text">IMS</span>
                    </Link>
                </div>
                <nav className="admin-nav">
                    <ul>
                        <li>
                            <Link to="/signup?context=addAdmin" className="nav-link add-admin-link">
                                <FontAwesomeIcon icon={faAdd} className="nav-icon" />
                                <span>Add Admin</span>
                            </Link>
                        </li>
                        <li>
                            <Link to="/admin/inventory" className="nav-link products-link">
                                <FontAwesomeIcon icon={faBoxOpen} className="nav-icon" />
                                <span>Products</span>
                            </Link>
                        </li>
                        <li>
                            <Link to="/admin/users" className="nav-link customers-link">
                                <FontAwesomeIcon icon={faUsers} className="nav-icon" />
                                <span>Customers</span>
                            </Link>
                        </li>
                        <li>
                            <Link to="/admin/orders" className="nav-link orders-link">
                                <FontAwesomeIcon icon={faShoppingCart} className="nav-icon" />
                                <span>Orders</span>
                            </Link>
                        </li>
                        {/* Removed Notifications from sidebar */}
                        <li>
                            <Link to="/admin/stocks" className="nav-link stocks-link">
                                <FontAwesomeIcon icon={faWarehouse} className="nav-icon" />
                                <span>Stocks</span>
                            </Link>
                        </li>
                        <li>
                            <Link to="/admin/suppliers" className="nav-link suppliers-link">
                                <FontAwesomeIcon icon={faTruck} className="nav-icon" />
                                <span>Suppliers</span>
                            </Link>
                        </li>
                        <li>
                            <Link to="/admin/reports" className="nav-link reports-link">
                                <FontAwesomeIcon icon={faChartBar} className="nav-icon" />
                                <span>Reports</span>
                            </Link>
                        </li>
                    </ul>
                </nav>
                {/* Removed Logout from sidebar footer */}
            </aside>

            {/* Main Content */}
            <main className="admin-content">
                <div className="content-body">
                    <Outlet />
                </div>
            </main>
        </div>
    );
};

export default AdminDashboard;