import React from 'react';
import '../../CSS/AdminHomePage.css';
import welcomeImage from '../../Assets/welcomeImage.png'; // Import the image

const HomePage = () => {
    return (
        <div className="home-page-container">
            <div className="admin-home-text">
                <h1>Hello! Minnu.</h1>
                <p>Manage your products, customers, orders, suppliers, and reports efficiently.</p>
            </div>
            <div className="welcome-image">
                <img src={welcomeImage} alt="Inventory Management System Illustration" />
            </div>
        </div>
    );
};

export default HomePage;