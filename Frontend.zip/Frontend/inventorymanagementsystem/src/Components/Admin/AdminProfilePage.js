import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode'; // Correct import for jwt-decode
import { useNavigate } from 'react-router-dom';
import '../../CSS/AdminProfilePage.css'; // Import the CSS file
// import adminProfileImage from '../../Assets/adminProfile.webp'; 

const AdminProfile = () => {
    const navigate = useNavigate();
    const [adminProfile, setAdminProfile] = useState(null);
    const [error, setError] = useState('');
    const [isEditing, setIsEditing] = useState(false); // State to toggle edit mode
    const [updatedProfile, setUpdatedProfile] = useState({
        name: '',
        phNo: '',
        email: '',
    });

    useEffect(() => {
        const fetchAdminProfile = async () => {
            try {
                const token = localStorage.getItem('authToken'); // Get the JWT token
                if (!token) {
                    setError('No token found. Please log in again.');
                    navigate('/login');
                    return;
                }

                const decodedToken = jwtDecode(token); // Decode the token
                const email = decodedToken.sub; // Extract the email from the token
                console.log('Decoded Token:', decodedToken); // Debugging log

                // Fetch admin details using the email
                const response = await axios.get(`http://localhost:8080/api/customers/adminProfile?email=${email}`, {
                    headers: {
                        Authorization: `Bearer ${token}`, // Include the token in the request
                    },
                });
                setAdminProfile(response.data); // Set the admin profile data
                setUpdatedProfile(response.data); // Initialize the updated profile with current data
            } catch (err) {
                console.error('Error fetching admin profile:', err);
                setError('Failed to fetch admin profile. Please try again.');
            }
        };

        fetchAdminProfile();
    }, [navigate]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setUpdatedProfile((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    const handleUpdate = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('authToken');
            await axios.put(`http://localhost:8080/api/customers/update-profile`, updatedProfile, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            setAdminProfile(updatedProfile);
            setIsEditing(false);
            alert('Profile updated successfully!');
        } catch (err) {
            console.error('Error updating profile:', err);
            setError('Failed to update profile. Please try again.');
        }
    };

    if (error) {
        return <div className="error-message">{error}</div>;
    }

    if (!adminProfile) {
        return <div>Loading...</div>;
    }

    return (
        <div className="admin-profile-page-wrapper">
        <div className="admin-profile-container" >
            <h2>Admin Profile</h2>
            {isEditing ? (
                <form onSubmit={handleUpdate}>
                    <div className="form-group">
                        <label htmlFor="name">Name:</label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            value={updatedProfile.name}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="phNo">Phone Number:</label>
                        <input
                            type="tel"
                            id="phNo"
                            name="phNo"
                            value={updatedProfile.phNo}
                            onChange={handleInputChange}
                            pattern="^\d{10}$"
                            title="Phone number must be 10 digits"
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="email">Email:</label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value={updatedProfile.email}
                            onChange={handleInputChange}
                            disabled
                            className="disabled-field"
                        />
                    </div>
                    <div className="button-container">
                        <button type="submit" className="adminprimary-button">Save</button>
                        <button
                            type="button"
                            className="adminsecondary-button"
                            onClick={() => setIsEditing(false)}
                        >
                            Cancel
                        </button>
                    </div>
                </form>
            ) : (
                <>
                    <p><strong>Name:</strong> {adminProfile.name}</p>
                    <p><strong>Phone Number:</strong> {adminProfile.phNo}</p>
                    <p><strong>Email:</strong> {adminProfile.email}</p>
                    <div className="button-container">
                        <button
                            className="adminupdate-button"
                            onClick={() => setIsEditing(true)}
                        >
                            Update
                        </button>
                        <button className="admingo-back-button" onClick={() => navigate('/admin')}>
                            Go Back
                        </button>
                    </div>
                </>
            )}
        </div>
        </div>
    );
};

export default AdminProfile;