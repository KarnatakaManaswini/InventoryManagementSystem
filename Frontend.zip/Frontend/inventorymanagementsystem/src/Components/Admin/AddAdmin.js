import  { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const AddAdmin = () => {
    const navigate = useNavigate();

    useEffect(() => {
        // Redirect to the Signup Page
        navigate('/signup?context=addAdmin');
    }, [navigate]);

    return null; // No UI is needed since it's just a redirect
};

export default AddAdmin;