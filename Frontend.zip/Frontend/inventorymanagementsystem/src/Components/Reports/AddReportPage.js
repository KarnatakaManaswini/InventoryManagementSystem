import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/AddReportPage.css'; // Ensure correct path to the updated CSS

const AddReportPage = () => {
    const [reportType, setReportType] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [data, setData] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('authToken');
            await axios.post(
                'http://localhost:8080/api/reports/create',
                {
                    reportType,
                    startDate,
                    endDate,
                    data,
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );
            alert('Report added successfully!');
            navigate('/admin/reports');
        } catch (error) {
            setError('Failed to add report.');
            console.error('Error adding report:', error);
        }
    };

    return (
        <div className="add-report-wrapper"> {/* Added wrapper div */}
            <div className="add-report-container"> {/* Updated container class */}
                <h2 className="add-report-container h2">Add Report</h2>
                <form className="add-report-form" onSubmit={handleSubmit}> {/* Updated form class */}
                    {error && <p className="error-message">{error}</p>}
                    <div className="form-group">
                        <label htmlFor="reportType">Report Type:</label>
                        <select
                            id="reportType"
                            value={reportType}
                            onChange={(e) => setReportType(e.target.value)}
                            required
                        >
                            <option value="">Select Report Type</option>
                            <option value="Inventory">Inventory</option>
                            <option value="Supplier">Supplier</option>
                            <option value="Order">Order</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label htmlFor="startDate">Start Date:</label>
                        <input
                            type="date"
                            id="startDate"
                            value={startDate}
                            onChange={(e) => setStartDate(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="endDate">End Date:</label>
                        <input
                            type="date"
                            id="endDate"
                            value={endDate}
                            onChange={(e) => setEndDate(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="data">Data:</label>
                        <textarea
                            id="data"
                            value={data}
                            onChange={(e) => setData(e.target.value)}
                            required
                        />
                    </div>
                    <div className="button-group"> {/* Updated to button-group */}
                        <button
                            type="button"
                            className="button secondary-button"
                            onClick={() => navigate('/admin/reports')}
                        >
                            Cancel
                        </button>
                        <button type="submit" className="button primary-button">
                            Add Report
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddReportPage;