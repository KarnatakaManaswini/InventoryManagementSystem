import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/UpdateReportPage.css'; // Ensure correct path to the CSS

const UpdateReportPage = () => {
    const { reportId } = useParams();
    const [reportType, setReportType] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [data, setData] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchReport = async () => {
            setLoading(true);
            try {
                const token = localStorage.getItem('authToken');
                if (!token) {
                    navigate('/login');
                    return;
                }
                const { data: report } = await axios.get(`http://localhost:8080/api/reports/getReportById/${reportId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setReportType(report.reportType);
                setStartDate(report.startDate);
                setEndDate(report.endDate);
                setData(report.data);
                setLoading(false);
            } catch (error) {
                setError('Failed to fetch report details.');
                setLoading(false);
                console.error('Error fetching report:', error);
            }
        };

        fetchReport();
    }, [reportId, navigate]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('authToken');
            if (!token) {
                navigate('/login');
                return;
            }
            await axios.put(
                `http://localhost:8080/api/reports/updateData/${reportId}`,
                {
                    reportType,
                    startDate,
                    endDate,
                    data,
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );
            alert('Report updated successfully!');
            navigate('/admin/reports');
        } catch (error) {
            setError('Failed to update report.');
            console.error('Error updating report:', error);
        }
    };

    if (loading) return <p>Loading report details...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div className="update-report-wrapper"> {/* Using consistent wrapper */}
            <div className="update-report-container"> {/* Using consistent container */}
                <h2 className="update-report-container h2">Update Report</h2>
                <form className="update-supplier-form" onSubmit={handleSubmit}> {/* Using consistent form */}
                    {error && <p className="error-message">{error}</p>}
                    <div className="form-group">
                        <label htmlFor="reportType">Report Type:</label>
                        <select
                            id="reportType"
                            value={reportType}
                            onChange={(e) => setReportType(e.target.value)}
                            required
                        >
                            <option value="">Select Report Type</option>
                            <option value="Inventory">Inventory</option>
                            <option value="Supplier">Supplier</option>
                            <option value="Order">Order</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label htmlFor="startDate">Start Date:</label>
                        <input
                            type="date"
                            id="startDate"
                            value={startDate}
                            onChange={(e) => setStartDate(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="endDate">End Date:</label>
                        <input
                            type="date"
                            id="endDate"
                            value={endDate}
                            onChange={(e) => setEndDate(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="data">Data:</label>
                        <textarea
                            id="data"
                            value={data}
                            onChange={(e) => setData(e.target.value)}
                            required
                        />
                    </div>
                    <div className="button-group"> {/* Using consistent button group */}
                        <button
                            type="button"
                            className="button secondaryreport-button"
                            onClick={() => navigate('/admin/reports')}
                        >
                            Cancel
                        </button>
                        <button type="submit" className="button primaryreport-button">
                            Update Report
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default UpdateReportPage;