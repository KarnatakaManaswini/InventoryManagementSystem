import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/ReportListPage.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrash, faPlus, faSearch, faBoxOpen } from '@fortawesome/free-solid-svg-icons';

const ReportListPage = () => {
    const [reports, setReports] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredReports, setFilteredReports] = useState([]);
    const token = localStorage.getItem('authToken');

    useEffect(() => {
        const fetchReports = async () => {
            setLoading(true);
            try {
                const response = await axios.get('http://localhost:8080/api/reports/findAllReports', {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setReports(response.data);
                setLoading(false);
            } catch (error) {
                setError('Failed to fetch reports.');
                setLoading(false);
                console.error('Error fetching reports:', error);
            }
        };

        fetchReports();
    }, [navigate, token]);

    useEffect(() => {
        const filterReports = () => {
            const lowerCaseSearchTerm = searchTerm.toLowerCase();
            const results = reports.filter(report =>
                String(report.reportId).includes(lowerCaseSearchTerm) ||
                report.reportType.toLowerCase().includes(lowerCaseSearchTerm) ||
                (report.startDate && report.startDate.toLowerCase().includes(lowerCaseSearchTerm)) ||
                (report.endDate && report.endDate.toLowerCase().includes(lowerCaseSearchTerm)) ||
                report.data.toLowerCase().includes(lowerCaseSearchTerm)
            );
            setFilteredReports(results);
        };

        filterReports();
    }, [searchTerm, reports]);

    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value);
    };

    const handleDelete = async (reportId) => {
        if (window.confirm('Are you sure you want to delete this report?')) {
            try {
                await axios.delete(`http://localhost:8080/api/reports/deleteById/${reportId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setReports(reports.filter((report) => report.reportId !== reportId));
                alert('Report deleted successfully.');
            } catch (error) {
                console.error('Error deleting report:', error);
                alert('Failed to delete report.');
            }
        }
    };

    if (loading) return <div className="loading-container">Loading reports...</div>;
    if (error) return <div className="error-container">Error: {error}</div>;

    return (
        <div className="report-list-container"> {/* Updated class name */}
            <div className="report-list-header"> {/* Updated class name */}
                <h2>Report List</h2>
                <div className="report-actions"> {/* Updated class name */}
                    <div className="search-container"> {/* Kept */}
                        <input
                            type="text"
                            className="search-input"
                            placeholder="Search reports..."
                            value={searchTerm}
                            onChange={handleSearchChange}
                        />
                        <button className="search-button">
                            <FontAwesomeIcon icon={faSearch} />
                        </button>
                    </div>
                    <button className="button addreport-button" onClick={() => navigate('/admin/reports/add')}>
                        <FontAwesomeIcon icon={faPlus} /> Add Report
                    </button>
                </div>
            </div>
            <div className="report-table-container"> {/* Updated class name */}
                {filteredReports.length > 0 ? (
                    <table className="report-table"> {/* Updated class name */}
                        <thead>
                            <tr>
                                <th>Report Type</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Data</th>
                                <th className="actions-column">Actions</th> {/* Kept */}
                            </tr>
                        </thead>
                        <tbody>
                            {filteredReports.map((report) => (
                                <tr key={report.reportId}>
                                    <td>{report.reportType}</td>
                                    <td>{report.startDate}</td>
                                    <td>{report.endDate}</td>
                                    <td className="report-data-cell">{report.data}</td>
                                    <td className="actions-column"> {/* Kept */}
                                        <button
                                            className="button action-button updatereport-button"
                                            onClick={() => navigate(`/admin/reports/edit/${report.reportId}`)}
                                        >
                                            <FontAwesomeIcon icon={faEdit} /> Update
                                        </button>
                                        <button
                                            className="button action-button deletereport-button" 
                                            onClick={() => handleDelete(report.reportId)}
                                        >
                                            <FontAwesomeIcon icon={faTrash} /> Delete
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div className="no-reports-container"> {/* Updated class name */}
                        <div className="no-reports"> {/* Updated class name */}
                            <FontAwesomeIcon icon={faBoxOpen} className="empty-icon" />
                            <p>{searchTerm ? 'No reports found matching your search.' : 'No reports available.'}</p>
                            {/* <button className="button add-button" onClick={() => navigate('/admin/reports/add')}>
                                <FontAwesomeIcon icon={faPlus} /> Add Report
                            </button> */}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ReportListPage;