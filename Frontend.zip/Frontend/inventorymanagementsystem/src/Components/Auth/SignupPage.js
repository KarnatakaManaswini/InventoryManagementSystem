import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import '../../CSS/AuthStyles.css'; // Assuming CSS is in src/components/css
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faWarehouse } from '@fortawesome/free-solid-svg-icons';
const SignupPage = () => {
  const [name, setName] = useState('');
  const [phNo, setPhNo] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const context = searchParams.get('context');
  const handleSignup = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    try {
      // Prepare the request payload
      const payload = {
        name,
        phNo,
        email,
        password,
      };

      // Prepare the headers
      const headers = {};
      if (context === 'addAdmin') {
        // If adding an admin, include the Authorization header with the token
        const token = localStorage.getItem('authToken');
        if (!token) {
          setError('You must be logged in as an admin to add another admin.');
          return;
        }
        headers.Authorization = `Bearer ${token}`;
      }

      // Make the API request
      const response = await axios.post(
        context === 'addAdmin'
          ? 'http://localhost:8080/api/customers/addAdmin' // Backend endpoint for adding admin
          : 'http://localhost:8080/api/customers/register', // Backend endpoint for customer registration
        payload,
        { headers } // Include headers conditionally
      );

      setSuccessMessage(response.data);

      // Navigate based on the context
      if (context === 'addAdmin') {
        navigate('/admin'); // Redirect to Admin Dashboard
      } else {
        navigate('/login'); // Redirect to Login Page for initial signup
      }
    } catch (error) {
      if (error.response && error.response.data) {
        setError(error.response.data.message || 'Signup failed. Please try again.');
      } else {
        setError('Signup failed. Please try again.');
      }
    }
  };

  const goToWelcomePage = () => {
    if (context !== 'addAdmin') {
      navigate('/');
    }
  };

  return (
    <div className="auth-container">
     <div
        className="auth-header"
        onClick={goToWelcomePage}
        style={{ cursor: context !== 'addAdmin' ? 'pointer' : 'default' }}
      >
        <FontAwesomeIcon icon={faWarehouse} className="auth-icon" />
        <span className="auth-title">IMS</span>
      </div>
      <div className="signup-container">
        <h2>{context === 'addAdmin' ? 'Add Admin' : 'Sign Up'}</h2>
        {error && <div className="error-message">{error}</div>}
        {successMessage && <div className="success-message">{successMessage}</div>}
        <form onSubmit={handleSignup}>
          <div className="auth-form-group">
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your full name"
              required
            />
          </div>
          <div className="auth-form-group">
            <label htmlFor="phNo">Phone Number:</label>
            <input
              type="tel"
              id="phNo"
              value={phNo}
              onChange={(e) => setPhNo(e.target.value)}
              pattern="^\d{10}$"
              title="Phone number must be 10 digits"
              placeholder="Enter your phone number"
              required
            />
          </div>
          <div className="auth-form-group">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email address"
              required
            />
          </div>
          <div className="auth-form-group">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              minLength="6"
              required
            />
          </div>
          <button type="submit" className="signup-button">{context === 'addAdmin' ? 'Add Admin' : 'Sign Up'}</button>
        </form>
        {context !== 'addAdmin' && (
          <p className="login-link">
            Already have an account? <Link to="/login" className="link-button">Log In</Link>
          </p>
        )}
        <div className="add-admin-container"> {/* Assuming this is your main container */}
    {/* Other form elements */}
    <div className="add-admin-actions"> {/* The parent for the button */}
      {context === 'addAdmin' && (
        <button
          className="addadmin-go-back-button"
          onClick={() => navigate('/admin')}
        >
          Go Back
        </button>
      )}
    </div>
  </div>
      </div>
    </div>
  );
};

export default SignupPage;