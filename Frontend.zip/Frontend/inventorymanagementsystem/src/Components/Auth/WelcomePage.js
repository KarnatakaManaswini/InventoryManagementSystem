// src/Components/WelcomePage.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../../CSS/WelcomePage.css'; 

const WelcomePage = () => {
  const navigate = useNavigate();

  const goToLogin = () => {
    navigate('/login');
  };

  const goToSignup = () => {
    navigate('/signup');
  };

  return (
    <div className="welcome-page">
      <div className="header-buttons">
        <button onClick={goToLogin}>Login</button>
        <button onClick={goToSignup}>Sign Up</button>
      </div>
      <div className="welcome-text">
        <h1>Welcome to Inventory Management System</h1>
        <p>Efficiently manage your inventory and streamline your operational workflows.</p>
      </div>
    </div>
  );
};

export default WelcomePage;