import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import '../../CSS/AuthStyles.css'; // Assuming CSS is in src/components/css
import { jwtDecode } from 'jwt-decode'; // Correct import for jwtDecode
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faWarehouse } from '@fortawesome/free-solid-svg-icons';
const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const response = await axios.post('http://localhost:8080/api/customers/login', {
        email,
        password,
      });
  
      console.log('Response Data:', response.data); // Debugging: Check the entire response
  
      // Extract the JWT from the response string
      const tokenString = response.data;
      const jwtStartIndex = tokenString.indexOf("JWT Token: ") + "JWT Token: ".length;
      const token = tokenString.substring(jwtStartIndex);
  
      console.log('Token before decode:', token); // Debugging: Check the token value
  
      localStorage.setItem('authToken', token);
  
      try {
        const decodedToken = jwtDecode(token);
        const roles = decodedToken.roles;
  
        if (roles && roles.length > 0) {
          const authority = roles[0].authority; // Assuming the first role is the main one
  
          if (authority === 'ROLE_ADMIN') {
            navigate('/admin');
          } else if (authority === 'ROLE_CUSTOMER') {
            navigate('/customer');
          } else {
            setError('Invalid role authority in JWT.');
          }
        } else {
          setError('No roles found in JWT.');
        }
      } catch (decodeError) {
        setError('Failed to decode JWT.');
        console.error('JWT Decode Error:', decodeError);
      }
    } catch (error) {
      if (error.response && error.response.data && error.response.data.message) {
        setError(error.response.data.message);
      } else {
        setError('Login failed. Please check your credentials and try again.');
      }
    }
  };

  const goToWelcomePage = () => {
    navigate('/');
  };
  
  return (
    <div className="auth-container">
   <div className="auth-header" onClick={goToWelcomePage} style={{ cursor: 'pointer' }}>
        <FontAwesomeIcon icon={faWarehouse} className="auth-icon" />
        <span className="auth-title">IMS</span>
      </div>
    
    <div className="login-container">
      <h2>Login</h2>
      {error && <div className="error-message">{error}</div>}
      <form onSubmit={handleLogin}>
        <div className="auth-form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email address"
            required
          />
        </div>
        <div className="auth-form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
            required
          />
        </div>
        <button type="submit" className="login-button">Login</button>
      </form>
      <p className="signup-link">
        Don't have an account? <Link to="/signup" className="link-button">Sign Up</Link>
      </p>
    </div>
    </div>
  );
};

export default LoginPage;