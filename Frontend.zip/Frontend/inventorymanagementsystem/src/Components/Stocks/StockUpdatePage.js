import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/StockUpdatePage.css'; // Ensure correct path to the CSS

const StockUpdatePage = () => {
    const { productId } = useParams();
    const [quantity, setQuantity] = useState('');
    const [reorderLevel, setReorderLevel] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchStock = async () => {
            setLoading(true);
            try {
                const token = localStorage.getItem('authToken');
                if (!token) {
                    navigate('/login');
                    return;
                }
                const { data: stock } = await axios.get(`http://localhost:8080/api/stocks/getStockById/${productId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setQuantity(stock.quantity);
                setReorderLevel(stock.reorderLevel);
                setLoading(false);
            } catch (error) {
                setError('Failed to fetch stock details.');
                setLoading(false);
                console.error('Error fetching stock:', error);
            }
        };

        fetchStock();
    }, [productId, navigate]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('authToken');
            if (!token) {
                navigate('/login');
                return;
            }
            await axios.put(
                `http://localhost:8080/api/stocks/update/${productId}?newQuantity=${quantity}`,
                { productId, quantity, reorderLevel },
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );
            alert('Stock updated successfully!');
            navigate('/admin/stocks');
        } catch (error) {
            setError('Failed to update stock.');
            console.error('Error updating stock:', error);
        }
    };

    if (loading) return <div className="loading-container">Loading stock details...</div>;
    if (error) return <div className="error-container">Error: {error}</div>;

    return (
        <div className="new-stock-wrapper"> {/* Using wrapper for consistency */}
            <div className="update-stock-container"> {/* Using the specific container class from UpdateReportPage */}
                <h2 className="update-stock-container h2">Update Stock</h2> {/* Using the specific header class from UpdateReportPage */}
                {error && <p className="error-message">{error}</p>}
                <form className="add-stock-form" onSubmit={handleSubmit}> {/* Using a form class that likely has consistent styling */}
                    <div className="form-group">
                        <label htmlFor="quantity">Quantity:</label>
                        <input
                            type="number"
                            id="quantity"
                            value={quantity}
                            onChange={(e) => setQuantity(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="reorderLevel">Reorder Level:</label>
                        <input
                            type="number"
                            id="reorderLevel"
                            value={reorderLevel}
                            onChange={(e) => setReorderLevel(e.target.value)}
                            required
                        />
                    </div>
                    <div className="button-group"> {/* Using the button container class from UpdateReportPage */}
                        <button
                            type="button"
                            className="button secondarystock-button"
                            onClick={() => navigate('/admin/stocks')}
                        >
                            Cancel
                        </button>
                        <button type="submit" className="button primarystock-button">
                            Update Stock
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default StockUpdatePage;