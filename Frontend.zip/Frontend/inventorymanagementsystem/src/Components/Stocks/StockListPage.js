import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/StockListPage.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faBoxOpen, faSearch } from '@fortawesome/free-solid-svg-icons';

const StockListPage = () => {
    const [stocks, setStocks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredStocks, setFilteredStocks] = useState([]);

    useEffect(() => {
        const fetchStocks = async () => {
            setLoading(true);
            try {
                const token = localStorage.getItem('authToken');
                const response = await axios.get('http://localhost:8080/api/stocks/getAll', {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setStocks(response.data);
                setLoading(false);
            } catch (error) {
                setError('Failed to fetch stocks.');
                setLoading(false);
                console.error('Error fetching stocks:', error);
            }
        };

        fetchStocks();
    }, [navigate]);

    useEffect(() => {
        const filterStocks = () => {
            const lowerCaseSearchTerm = searchTerm.toLowerCase();
            const results = stocks.filter(stock =>
                stock.productName.toLowerCase().includes(lowerCaseSearchTerm) ||
                String(stock.quantity).includes(lowerCaseSearchTerm) ||
                String(stock.reorderLevel).includes(lowerCaseSearchTerm)
            );
            setFilteredStocks(results);
        };

        filterStocks();
    }, [searchTerm, stocks]);

    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value);
    };

    if (loading) return <div className="loading-container">Loading stocks...</div>;
    if (error) return <div className="error-container">Error: {error}</div>;

    return (
        <div className="stock-list-container">
            <div className="stock-list-header">
                <h2>Stock List</h2>
                <div className="stock-actions">
                    <div className="search-container">
                        <input
                            type="text"
                            className="search-input"
                            placeholder="Search stocks..."
                            value={searchTerm}
                            onChange={handleSearchChange}
                        />
                        <button className="search-button">
                            <FontAwesomeIcon icon={faSearch} />
                        </button>
                    </div>
                    {/* You can add other actions here if needed */}
                </div>
            </div>
            <div className="stock-table-container">
                {filteredStocks.length > 0 ? (
                    <table className="stock-table">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Quantity</th>
                                <th>Reorder Level</th>
                                <th className="actions-column">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredStocks.map((stock) => (
                                <tr key={stock.productId}>
                                    <td>{stock.productName}</td>
                                    <td>{stock.quantity}</td>
                                    <td>{stock.reorderLevel}</td>
                                    <td className="actions-column">
                                        <button
                                            className="button action-button edit-button"
                                            onClick={() => navigate(`/admin/stocks/edit/${stock.productId}`)}
                                        >
                                            <FontAwesomeIcon icon={faEdit} /> Update Stock
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div className="no-stocks-container">
                        <div className="no-stocks">
                            <FontAwesomeIcon icon={faBoxOpen} className="empty-icon" />
                            <p>{searchTerm ? 'No stocks found matching your search.' : 'No stocks available.'}</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default StockListPage;