import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/AddSupplierPage.css'; // Ensure correct path to the updated CSS

const AddSupplierPage = () => {
    const [name, setName] = useState('');
    const [contactInfo, setContactInfo] = useState('');
    const [productsSupplied, setProductsSupplied] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('authToken');
            await axios.post(
                'http://localhost:8080/api/suppliers/add',
                {
                    name,
                    contactInfo,
                    productsSupplied: productsSupplied.split(',').map((product) => product.trim()),
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );
            alert('Supplier added successfully!');
            navigate('/admin/suppliers');
        } catch (error) {
            setError('Failed to add supplier.');
            console.error('Error adding supplier:', error);
        }
    };

    return (
        <div className="add-supplier-wrapper"> {/* Added wrapper div */}
            <div className="add-supplier-container"> {/* Updated container class */}
                <h2 className="add-supplier-container h2">Add Supplier</h2>
                <form className="add-supplier-form" onSubmit={handleSubmit}> {/* Updated form class */}
                    {error && <p className="error-message">{error}</p>}
                    <div className="form-group">
                        <label htmlFor="name">Name:</label>
                        <input
                            type="text"
                            id="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="contactInfo">Contact Info:</label>
                        <input
                            type="text"
                            id="contactInfo"
                            value={contactInfo}
                            onChange={(e) => setContactInfo(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="productsSupplied">Products Supplied (comma-separated):</label>
                        <input
                            type="text"
                            id="productsSupplied"
                            value={productsSupplied}
                            onChange={(e) => setProductsSupplied(e.target.value)}
                            required
                        />
                    </div>
                    <div className="button-group"> {/* Added button group */}
                        <button
                            type="button"
                            className="button secondary-button"
                            onClick={() => navigate('/admin/suppliers')}
                        >
                            Cancel
                        </button>
                        <button type="submit" className="button primary-button">
                            Add Supplier
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddSupplierPage;