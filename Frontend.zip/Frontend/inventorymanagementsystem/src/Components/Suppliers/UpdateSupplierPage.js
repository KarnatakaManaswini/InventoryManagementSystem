import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/UpdateSupplierPage.css'; // Ensure correct path to the CSS

const UpdateSupplierPage = () => {
    const { supplierId } = useParams();
    const [name, setName] = useState('');
    const [contactInfo, setContactInfo] = useState('');
    const [productsSupplied, setProductsSupplied] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchSupplier = async () => {
            setLoading(true);
            try {
                const token = localStorage.getItem('authToken');
                if (!token) {
                    navigate('/login');
                    return;
                }
                const { data: supplier } = await axios.get(`http://localhost:8080/api/suppliers/getById/${supplierId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setName(supplier.name);
                setContactInfo(supplier.contactInfo);
                setProductsSupplied(supplier.productsSupplied.join(', '));
                setLoading(false);
            } catch (error) {
                setError('Failed to fetch supplier details.');
                setLoading(false);
                console.error('Error fetching supplier:', error);
            }
        };

        fetchSupplier();
    }, [supplierId, navigate]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('authToken');
            if (!token) {
                navigate('/login');
                return;
            }
            await axios.put(
                `http://localhost:8080/api/suppliers/update/${supplierId}`,
                {
                    name,
                    contactInfo,
                    productsSupplied: productsSupplied.split(',').map((product) => product.trim()),
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );
            alert('Supplier updated successfully!');
            navigate('/admin/suppliers');
        } catch (error) {
            setError('Failed to update supplier.');
            console.error('Error updating supplier:', error);
        }
    };

    if (loading) return <p>Loading supplier details...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div className="update-supplier-wrapper"> {/* Using wrapper for consistency */}
            <div className="update-supplier-container"> {/* Using the specific container class */}
                <h2 className="update-supplier-container h2">Update Supplier</h2> {/* Using the specific header style */}
                <form className="update-supplier-form" onSubmit={handleSubmit}> {/* Using the specific form class */}
                    {error && <p className="error-message">{error}</p>}
                    <div className="form-group">
                        <label htmlFor="name">Name:</label>
                        <input
                            type="text"
                            id="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="contactInfo">Contact Info:</label>
                        <input
                            type="text"
                            id="contactInfo"
                            value={contactInfo}
                            onChange={(e) => setContactInfo(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="productsSupplied">Products Supplied (comma-separated):</label>
                        <input
                            type="text"
                            id="productsSupplied"
                            value={productsSupplied}
                            onChange={(e) => setProductsSupplied(e.target.value)}
                            required
                        />
                    </div>
                    <div className="button-group"> {/* Using the button group class */}
                        <button
                            type="button"
                            className="button secondarysupplier-button"
                            onClick={() => navigate('/admin/suppliers')}
                        >
                            Cancel
                        </button>
                        <button type="submit" className="button primarysupplier-button">
                            Update Supplier
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default UpdateSupplierPage;