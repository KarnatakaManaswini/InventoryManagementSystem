import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/DeleteSupplierPage.css';

const DeleteSupplierPage = () => {
    const { supplierId } = useParams();
    const [supplier, setSupplier] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchSupplier = async () => {
            setLoading(true);
            try {
                const token = localStorage.getItem('authToken'); // Retrieve token from localStorage
                if (!token) {
                    navigate('/login'); // Redirect to login if token is missing
                    return;
                }
                const { data } = await axios.get(`http://localhost:8080/api/suppliers/getById/${supplierId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`, // Add Authorization header
                    },
                });
                setSupplier(data);
                setLoading(false);
            } catch (error) {
                setError('Failed to fetch supplier details.');
                setLoading(false);
                console.error('Error fetching supplier:', error);
            }
        };

        fetchSupplier();
    }, [supplierId, navigate]);

    const handleDelete = async () => {
        try {
            const token = localStorage.getItem('authToken'); // Retrieve token from localStorage
            if (!token) {
                navigate('/login'); // Redirect to login if token is missing
                return;
            }
            await axios.delete(`http://localhost:8080/api/suppliers/deleteById/${supplierId}`, {
                headers: {
                    Authorization: `Bearer ${token}`, // Add Authorization header
                },
            });
            alert('Supplier deleted successfully!');
            navigate('/admin/suppliers');
        } catch (error) {
            setError('Failed to delete supplier.');
            console.error('Error deleting supplier:', error);
        }
    };

    if (loading) return <p>Loading supplier details...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div className="delete-supplier-container">
            <h2>Delete Supplier</h2>
            {supplier && (
                <div className="supplier-details">
                    <p><strong>Name:</strong> {supplier.name}</p>
                    <p><strong>Contact Info:</strong> {supplier.contactInfo}</p>
                    <p><strong>Products Supplied:</strong> {supplier.productsSupplied.join(', ')}</p>
                </div>
            )}
            <p>Are you sure you want to delete this supplier?</p>
            <button className="button delete-button" onClick={handleDelete}>
                Yes, Delete
            </button>
            <button
                className="button cancel-button"
                onClick={() => navigate('/admin/suppliers')}
            >
                Cancel
            </button>
        </div>
    );
};

export default DeleteSupplierPage;