import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../CSS/SupplierListPage.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrash, faPlus, faBoxOpen, faSearch } from '@fortawesome/free-solid-svg-icons';

const SupplierListPage = () => {
    const [suppliers, setSuppliers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredSuppliers, setFilteredSuppliers] = useState([]);

    useEffect(() => {
        const fetchSuppliers = async () => {
            setLoading(true);
            try {
                const token = localStorage.getItem('authToken');
                const response = await axios.get('http://localhost:8080/api/suppliers/getAll', {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setSuppliers(response.data);
                setLoading(false);
            } catch (error) {
                setError('Failed to fetch suppliers.');
                setLoading(false);
                console.error('Error fetching suppliers:', error);
            }
        };

        fetchSuppliers();
    }, [navigate]);

    useEffect(() => {
        const filterSuppliers = () => {
            const lowerCaseSearchTerm = searchTerm.toLowerCase();
            const results = suppliers.filter(supplier =>
                supplier.name.toLowerCase().includes(lowerCaseSearchTerm) ||
                supplier.contactInfo.toLowerCase().includes(lowerCaseSearchTerm) ||
                supplier.productsSupplied.join(', ').toLowerCase().includes(lowerCaseSearchTerm)
            );
            setFilteredSuppliers(results);
        };

        filterSuppliers();
    }, [searchTerm, suppliers]);

    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value);
    };

    const handleDelete = async (supplierId) => {
        if (window.confirm('Are you sure you want to delete this supplier?')) {
            try {
                const token = localStorage.getItem('authToken');
                await axios.delete(`http://localhost:8080/api/suppliers/deleteById/${supplierId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setSuppliers(suppliers.filter((supplier) => supplier.supplierId !== supplierId));
                alert('Supplier deleted successfully.');
            } catch (error) {
                console.error('Error deleting supplier:', error);
                alert('Failed to delete supplier.');
            }
        }
    };

    if (loading) return <div className="loading-container">Loading suppliers...</div>;
    if (error) return <div className="error-container">Error: {error}</div>;

    return (
        <div className="supplier-list-container">
            <div className="supplier-list-header">
                <h2>Supplier List</h2>
                <div className="supplier-actions">
                    <div className="search-container"> {/* Added search container */}
                        <input
                            type="text"
                            className="search-input"
                            placeholder="Search suppliers..."
                            value={searchTerm}
                            onChange={handleSearchChange}
                        />
                        <button className="search-button">
                            <FontAwesomeIcon icon={faSearch} />
                        </button>
                    </div>
                    <button className="button addsupplier-button" onClick={() => navigate('/admin/suppliers/add')}>
                        <FontAwesomeIcon icon={faPlus} /> Add Supplier
                    </button>
                </div>
            </div>
            <div className="supplier-table-container">
                {filteredSuppliers.length > 0 ? (
                    <table className="supplier-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Contact Info</th>
                                <th>Products Supplied</th>
                                <th className="actions-column">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredSuppliers.map((supplier) => (
                                <tr key={supplier.supplierId}>
                                    <td>{supplier.name}</td>
                                    <td>{supplier.contactInfo}</td>
                                    <td>{supplier.productsSupplied.join(', ')}</td>
                                    <td className="actions-column">
                                        <button
                                            className="button action-button updatesupplier-button"
                                            onClick={() => navigate(`/admin/suppliers/edit/${supplier.supplierId}`)}
                                        >
                                            <FontAwesomeIcon icon={faEdit} /> Update
                                        </button>
                                        <button
                                            className="button action-button deletesupplier-button"
                                            onClick={() => handleDelete(supplier.supplierId)}
                                        >
                                            <FontAwesomeIcon icon={faTrash} /> Delete
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div className="no-suppliers-container">
                        <div className="no-suppliers">
                            <FontAwesomeIcon icon={faBoxOpen} className="empty-icon" />
                            <p>{searchTerm ? 'No suppliers found matching your search.' : 'No suppliers available.'}</p>
                            {/* <button className="button add-button" onClick={() => navigate('/admin/suppliers/add')}>
                                <FontAwesomeIcon icon={faPlus} /> Add Supplier
                            </button> */}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default SupplierListPage;