create DATABASE  Inventory_Management_System;
Use Inventory_Management_System;
CREATE TABLE Product(ProductID INT primary KEY,
                     NAME VARCHAR(100) NOT NULL,
                     DESCRIPTION TEXT,
                     Price Decimal(10,2) NOT NULL,
                     StockLevel INT NOT NULL);

CREATE TABLE Customer(CustomerID int primary key,
					  name varchar(100) not null,
                      PhoneNo varchar(15),
                      Email varchar(50) not null);
	
 Create table Orderr(OrderID int primary key,
                    CustomerID int,
                    ProductID int,
                    Quantity int not null,
                    OrderDate DATE,
                    status varchar(20) CHECK (status IN('Pending','Shipped','Delivered')),
                    foreign key (CustomerID) REFERENCES Customer(CustomerID),
                    foreign key (ProductID) REFERENCES Product(ProductID));
          
create table stock (ProductID int primary key,
                   Quantity int not null,
                   ReorderLevel int not null,
                   foreign key (ProductID) references Product(ProductID));
                   
create table Supplier (SupplierID int primary key,
                       Name varchar(100),
                       ContactInfo VARCHAR(255),
                       ProductsSupplied TEXT);
                       
CREATE TABLE Report(ReportID int primary key,
                   ReportType VARCHAR(50) CHECK (ReportType IN ('Inventory','Order','Supplier')),
                   StartDate DATE,
                   EndDate DATE,
                   Data TEXT);
                     