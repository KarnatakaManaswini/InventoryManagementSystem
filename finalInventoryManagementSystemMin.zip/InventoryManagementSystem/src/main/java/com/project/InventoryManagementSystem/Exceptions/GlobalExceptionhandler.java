package com.project.InventoryManagementSystem.Exceptions;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import jakarta.servlet.http.HttpServletRequest;

@RestControllerAdvice
public class GlobalExceptionhandler {

	@ExceptionHandler(ProductNotFoundException.class)
	public ResponseEntity<ErrorDetails> handleProductNotFoundException(
			ProductNotFoundException ex, HttpServletRequest request) {

		ErrorDetails errorResponse = new ErrorDetails(
				LocalDateTime.now(),
				ex.getMessage(),
				request.getRequestURI());
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<ErrorDetails> HandleCustomerNotFoundException(CustomerNotFoundException ex,
			HttpServletRequest req) {
		ErrorDetails error = new ErrorDetails(
				LocalDateTime.now(),
				ex.getMessage(),
				req.getRequestURI());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(InsufficientStockException.class)
	public ResponseEntity<ErrorDetails> HandleInsufficeintStockException(InsufficientStockException ex,
			HttpServletRequest req) {
		ErrorDetails error = new ErrorDetails(
				LocalDateTime.now(),
				ex.getMessage(),
				req.getRequestURI());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(OrderNotFoundException.class)
	public ResponseEntity<ErrorDetails> HandleOrderNotFoundException(OrderNotFoundException ex,
			HttpServletRequest req) {
		ErrorDetails error = new ErrorDetails(
				LocalDateTime.now(),
				ex.getMessage(),
				req.getRequestURI());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(StockNotFoundException.class)
	public ResponseEntity<ErrorDetails> HandleStockNotFoundException(StockNotFoundException ex,
			HttpServletRequest req) {
		ErrorDetails error = new ErrorDetails(
				LocalDateTime.now(),
				ex.getMessage(),
				req.getRequestURI());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(SupplierNotFoundException.class)
	public ResponseEntity<ErrorDetails> HandleSupplierNotFoundException(SupplierNotFoundException ex,
			HttpServletRequest req) {
		ErrorDetails error = new ErrorDetails(
				LocalDateTime.now(),
				ex.getMessage(),
				req.getRequestURI());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(InventoryAPIBadRequestException.class)
	public ResponseEntity<ErrorDetails> HandleInventoryAPIException(InventoryAPIBadRequestException ex,
			HttpServletRequest req) {
		ErrorDetails error = new ErrorDetails(
				LocalDateTime.now(),
				ex.getMessage(),
				req.getRequestURI());
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(IdNotFoundException.class)
	public ResponseEntity<ErrorDetails> HandleIdNotFoundException(IdNotFoundException ex,
			HttpServletRequest req) {
		ErrorDetails error = new ErrorDetails(
				LocalDateTime.now(),
				ex.getMessage(),
				req.getRequestURI());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(ReportNotFoundException.class)
	public ResponseEntity<ErrorDetails> HandleResourceNotFoundException(ReportNotFoundException ex,
			HttpServletRequest req) {
		ErrorDetails error = new ErrorDetails(
				LocalDateTime.now(),
				ex.getMessage(),
				req.getRequestURI());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(InappropriateDateException.class)
	public ResponseEntity<ErrorDetails> HandleInappropriateDateException(InappropriateDateException ex,
			HttpServletRequest req) {
		ErrorDetails error = new ErrorDetails(
				LocalDateTime.now(),
				ex.getMessage(),
				req.getRequestURI());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorDetails> handleValidationExceptions(MethodArgumentNotValidException ex,
			HttpServletRequest request) {
		String details = "";
		for (ObjectError e : ex.getBindingResult().getAllErrors()) {
			details += e.getDefaultMessage() + ", ";
		}
		System.out.println("\n\n" + details + "\n\n");
		ErrorDetails errorResponse = new ErrorDetails(
				LocalDateTime.now(),
				details,
				request.getRequestURI());
		return new ResponseEntity<ErrorDetails>(errorResponse, HttpStatus.BAD_REQUEST);
	}
}
