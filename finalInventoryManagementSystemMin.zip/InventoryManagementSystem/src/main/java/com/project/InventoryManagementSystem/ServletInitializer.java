package com.project.InventoryManagementSystem;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

public class ServletInitializer extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(InventoryManagementSystemApplication.class);
	}

}

//this cls is used to deploy SBoot App to server like tomcat
//binds SpringApp Builder to the application context and configures it. &
// return a spring app builder instance