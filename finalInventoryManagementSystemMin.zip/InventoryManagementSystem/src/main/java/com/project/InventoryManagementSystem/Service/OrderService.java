package com.project.InventoryManagementSystem.Service;

import java.util.List;

import com.project.InventoryManagementSystem.DTO.OrderDto;
import com.project.InventoryManagementSystem.Entities.Order.Status;

public interface OrderService {
    OrderDto placeOrder(String email, long productId, int quantity);

    OrderDto updateOrderStatus(long orderId, Status status);

    String deleteOrderById(long orderId);

    void deleteAllOrders();

    List<OrderDto> getAllOrders();

    OrderDto getOrderById(long orderId);

    List<OrderDto> getOrderByProductName(String name);

    List<OrderDto> getOrdersByCustomerId(Long customerId);
}
