package com.project.InventoryManagementSystem.Controllers;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.InventoryManagementSystem.DTO.ReportDto;
import com.project.InventoryManagementSystem.Entities.Report.ReportType;
import com.project.InventoryManagementSystem.Service.Impl.ReportServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "http://localhost:3000")
public class ReportController {

    @Autowired
    private ReportServiceImpl reportService;

    @GetMapping("/getReportById/{id}")
    public ResponseEntity<ReportDto> getReportById(@PathVariable long id) {
        return new ResponseEntity<>(reportService.getReportById(id), HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<?> create(@Valid @RequestBody ReportDto reportDto) {
        String response = reportService.create(reportDto);
        return new ResponseEntity<>(response,HttpStatus.OK);
    }

    @GetMapping("/findAllReports")
    public ResponseEntity<List<ReportDto>> findAllReports() {
        return new ResponseEntity<>(reportService.findAllReports(), HttpStatus.OK);
    }

    @DeleteMapping("/deleteById/{id}")
    public ResponseEntity<String> deleteById(@PathVariable long id) {
        reportService.deleteById(id);
        return new ResponseEntity<>("Report ID " + id + " Deleted successfully", HttpStatus.OK);
    }

    @PutMapping("/updateData/{id}")
    public ResponseEntity<String> updateData(@PathVariable long id, @Valid @RequestBody ReportDto reportDto) {
        reportService.updateData(id, reportDto);
        return new ResponseEntity<>("Report ID" + id + " updated successfully", HttpStatus.OK);
    }

    @GetMapping("/getReportByReportType/{reportType}")
    public ResponseEntity<List<ReportDto>> getReportByReportType(@PathVariable ReportType reportType) {
        return new ResponseEntity<>(reportService.getReportByReportType(reportType), HttpStatus.OK);
    }

    @GetMapping("/getReportByDate")
    public ResponseEntity<List<ReportDto>> getReportByDate(@RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {
        return new ResponseEntity<>(reportService.getReportByDate(startDate, endDate), HttpStatus.OK);
    }
}