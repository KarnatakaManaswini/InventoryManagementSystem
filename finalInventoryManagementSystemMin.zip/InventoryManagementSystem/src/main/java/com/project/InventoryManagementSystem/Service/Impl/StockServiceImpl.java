package com.project.InventoryManagementSystem.Service.Impl;
 
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.project.InventoryManagementSystem.DTO.StockDto;
import com.project.InventoryManagementSystem.Entities.Notification;
import com.project.InventoryManagementSystem.Entities.Product;
import com.project.InventoryManagementSystem.Entities.Stock;
import com.project.InventoryManagementSystem.Exceptions.ProductNotFoundException;
import com.project.InventoryManagementSystem.Exceptions.StockNotFoundException;
import com.project.InventoryManagementSystem.Repository.NotificationRepository;
import com.project.InventoryManagementSystem.Repository.ProductRepository;
import com.project.InventoryManagementSystem.Repository.StockRepository;
import com.project.InventoryManagementSystem.Service.StockService;
 
import lombok.extern.slf4j.Slf4j;
 
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
 
@Service
@Slf4j
public class StockServiceImpl implements StockService {
 
    @Autowired
    private NotificationRepository notificationRepository;
 
    @Autowired
    private StockRepository stockRepository;
 
    @Autowired
    private ProductRepository productRepository;
 
    @Autowired
    private ModelMapper modelMapper;
   
    @Override
    public void sendNotification(long productId, int quantity, int reorderLevel) {
        log.warn("Sending notification for Product ID: {}. Stock level: {}, Reorder level: {}", productId, quantity, reorderLevel);
 
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> {
                    log.error("Product with ID {} not found", productId);
                    return new ProductNotFoundException("Product with ID " + productId + " not found");
                });
        String msg = "Admin Alert: Product " + product.getName()+
                " stock level (" + quantity + ") is below reorder level (" + reorderLevel + ").";
        Notification notification = new Notification();
        notification.setMessage(msg);
        notification.setDate(LocalDateTime.now());
        notificationRepository.save(notification);
 
        log.info("Notification saved for Product ID: {}", productId);
    }
 
    @Override
    public StockDto updateStockAndProductLevel(long productId, int newQuantity, StockDto stockDto) {
        log.info("Updating stock and product level for Product ID: {}", productId);
 
        Stock stock = stockRepository.findById(productId)
                .orElseThrow(() -> {
                    log.error("Stock not found for Product ID: {}", productId);
                    return new StockNotFoundException("Stock not found for Product ID: " + stockDto.getProductId());
                });
 
        StockDto stockDTO = modelMapper.map(stock, StockDto.class);
        stock.setQuantity(stockDTO.getQuantity() + newQuantity);
        stock.setReorderLevel(stockDto.getReorderLevel());
        stockRepository.save(stock);
        log.info("Stock updated for Product ID: {}. New quantity: {}", productId, stock.getQuantity());
 
        StockDto updatedStockDto = modelMapper.map(stock, StockDto.class);
        Product product = productRepository.findById(stockDTO.getProductId())
                .orElseThrow(() -> {
                    log.error("Product not found for ID: {}", stockDTO.getProductId());
                    return new ProductNotFoundException("Product not found for ID: " + stockDTO.getProductId());
                });
 
        product.setStockLevel(updatedStockDto.getQuantity());
        productRepository.save(product);
        log.info("Product stock level updated for Product ID: {}. New stock level: {}", productId, product.getStockLevel());
 
        if (stock.getQuantity() < stock.getReorderLevel()) {
            log.warn("Stock level below reorder level for Product ID: {}. Sending notification.", productId);
            sendNotification(stock.getProductId(), stock.getQuantity(), stock.getReorderLevel());
        }
 
        return updatedStockDto;
    }
 
    @Override
    public StockDto getStockById(long productId) {
        log.info("Fetching stock for Product ID: {}", productId);
 
        Stock stock = stockRepository.findById(productId)
                .orElseThrow(() -> {
                    log.error("Stock not found for Product ID: {}", productId);
                    return new StockNotFoundException("Stock not found for Product ID: " + productId);
                });
 
        log.info("Stock fetched successfully for Product ID: {}", productId);
        return modelMapper.map(stock, StockDto.class);
    }
 
    @Override
    public List<StockDto> getAllStock() {
        log.info("Fetching all stock records");
 
        List<Stock> stocks = stockRepository.findAll();
        log.info("Total stock records fetched: {}", stocks.size());
 
        return stocks.stream().map(stock -> {
            StockDto stockDto = new StockDto();
            stockDto.setProductId(stock.getProduct().getProductId());
            stockDto.setProductName(stock.getProduct().getName()); // Set the product name
            stockDto.setQuantity(stock.getQuantity());
            stockDto.setReorderLevel(stock.getReorderLevel());
            return stockDto;
        }).collect(Collectors.toList());
    }
}