package com.project.InventoryManagementSystem.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SupplierDto {

    private int supplierId;

    @NotBlank(message = "Supplier name cannot be blank")
    private String name;

    @NotBlank(message = "Contact info cannot be blank")
    private String contactInfo;

    @NotEmpty(message = "Products supplied cannot be empty")
    private List<String> productsSupplied;
}