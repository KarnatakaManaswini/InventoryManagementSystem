package com.project.InventoryManagementSystem.DTO;

import java.time.LocalDateTime;
import lombok.Data;

@Data
public class NotificationDto {

    private long id;

    private String message;

    private LocalDateTime date;
}
