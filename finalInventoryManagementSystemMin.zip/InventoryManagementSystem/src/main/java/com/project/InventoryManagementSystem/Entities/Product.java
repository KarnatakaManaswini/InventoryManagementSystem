package com.project.InventoryManagementSystem.Entities;
 
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;
 
@Entity  //mark cls as jpa entity, table is created in db
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "products")
public class Product {
 
    @Id      //specifies P key    // specifies how P key is generated
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long productId;
 
    @NotEmpty(message = "Product Name should not be null or empty")
    private String name;
 
    @NotBlank(message = "Description should not be blank")
    private String description;
 
    @Min(value = 1, message = "Price must be at least 1")
    @Column(nullable = false)
    private int price;
 
    @Min(value = 0, message = "Stock level cannot be negative")
    @Column(nullable = false)
    private int stockLevel;
 
    @OneToOne(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference   // Prevents infinite recursion in bi-directional relationships during JSON serialization by managing the parent side.
    private Stock stock;
    
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Order> orders;
}