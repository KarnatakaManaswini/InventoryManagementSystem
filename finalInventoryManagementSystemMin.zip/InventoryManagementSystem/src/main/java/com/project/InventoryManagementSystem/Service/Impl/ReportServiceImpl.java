package com.project.InventoryManagementSystem.Service.Impl;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.InventoryManagementSystem.DTO.ReportDto;
import com.project.InventoryManagementSystem.Entities.Report;
import com.project.InventoryManagementSystem.Entities.Report.ReportType;
import com.project.InventoryManagementSystem.Exceptions.IdNotFoundException;
import com.project.InventoryManagementSystem.Exceptions.InappropriateDateException;
import com.project.InventoryManagementSystem.Exceptions.InventoryAPIBadRequestException;
import com.project.InventoryManagementSystem.Exceptions.ReportNotFoundException;
import com.project.InventoryManagementSystem.Repository.ReportRepository;
import com.project.InventoryManagementSystem.Service.ReportService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j 
public class ReportServiceImpl implements ReportService{

    @Autowired
    private ReportRepository reportRepo;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public String create(ReportDto reportDto) {
        log.info("Creating a new report with type: {}", reportDto.getReportType());
    
        
        if (reportDto.getStartDate().isAfter(reportDto.getEndDate())) {
            log.error("Validation failed: startDate {} is after endDate {}", reportDto.getStartDate(), reportDto.getEndDate());
            throw new InventoryAPIBadRequestException("Start date must be earlier than end date");
        }
    
        
        Report report = modelMapper.map(reportDto, Report.class);
    
        
        reportRepo.save(report);
        log.info("Successfully created a report with ID: {}", report.getReportId());
        return "Successfully created an entry with report ID : " + report.getReportId();
    }

    @Override
    public ReportDto getReportById(long id) {
        log.info("Fetching report with ID: {}", id);
        Report report = reportRepo.findById(id)
                .orElseThrow(() -> {
                    log.error("Report with ID {} not found", id);
                    return new IdNotFoundException("Id not found");
                });
        log.info("Report with ID {} fetched successfully", id);
        return modelMapper.map(report, ReportDto.class);
    }

    @Override
    public List<ReportDto> findAllReports() {
        log.info("Fetching all reports");
        List<ReportDto> reports = reportRepo.findAll().stream()
                .map(report -> modelMapper.map(report, ReportDto.class))
                .collect(Collectors.toList());
        log.info("Total reports fetched: {}", reports.size());
        return reports;
    }

    @Override
    public void deleteById(long id) {
        log.info("Deleting report with ID: {}", id);
        if (!reportRepo.existsById(id)) {
            log.error("Report with ID {} not found for deletion", id);
            throw new IdNotFoundException("Report Id " + id + " not found");
        }
        reportRepo.deleteById(id);
        log.info("Report with ID {} deleted successfully", id);
    }
    
    public void updateData(long id, ReportDto reportDto) {
        log.info("Updating report with ID: {}", id);
        Report existingReport = reportRepo.findById(id)
        .orElseThrow(() -> {
            log.error("Report with ID {} not found for update", id);
            return new IdNotFoundException("Report Id " + id + " not found");
        });
        Report updatedReport = modelMapper.map(reportDto, Report.class);
        updatedReport.setReportId(existingReport.getReportId()); 
        reportRepo.save(updatedReport);
        log.info("Report with ID {} updated successfully", id);
    }
    
    public List<ReportDto> getReportByReportType(ReportType reportType) {
        log.info("Fetching reports with type: {}", reportType);
        List<Report> reports = reportRepo.findByReportType(reportType);
        if (reports.isEmpty()) {
            log.error("No reports found with type: {}", reportType);
            throw new ReportNotFoundException("Report not found");
        }
        log.info("Total reports fetched with type {}: {}", reportType, reports.size());
        return reports.stream()
        .map(report -> modelMapper.map(report, ReportDto.class))
        .collect(Collectors.toList());
    }
    
    @Override
    public List<ReportDto> getReportByDate(LocalDate startDate, LocalDate endDate) {
        log.info("Fetching reports between dates: {} and {}", startDate, endDate);
        List<Report> reports = reportRepo.findByStartDateBetween(startDate, endDate);
        if (reports.isEmpty()) {
            log.error("No reports found between dates: {} and {}", startDate, endDate);
            throw new InappropriateDateException("Enter correct date");
        }
        log.info("Total reports fetched between dates {} and {}: {}", startDate, endDate, reports.size());
        return reports.stream()
                .map(report -> modelMapper.map(report, ReportDto.class))
                .collect(Collectors.toList());
    }
}