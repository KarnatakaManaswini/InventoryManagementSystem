package com.project.InventoryManagementSystem.Exceptions;

public class InventoryAPIBadRequestException extends RuntimeException{
    public InventoryAPIBadRequestException(String message){
        super(message);
    }
}
