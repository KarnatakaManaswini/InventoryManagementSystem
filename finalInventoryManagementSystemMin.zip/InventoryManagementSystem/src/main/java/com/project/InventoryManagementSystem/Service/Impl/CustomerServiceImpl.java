package com.project.InventoryManagementSystem.Service.Impl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.project.InventoryManagementSystem.Security.JwtUtil;
import com.project.InventoryManagementSystem.DTO.CustomerProfile;
import com.project.InventoryManagementSystem.DTO.CustomerUpdateRequest;
import com.project.InventoryManagementSystem.DTO.LoginRequest;
import com.project.InventoryManagementSystem.DTO.RegisterRequest;
import com.project.InventoryManagementSystem.Entities.Customer;
import com.project.InventoryManagementSystem.Exceptions.CustomerNotFoundException;
import com.project.InventoryManagementSystem.Exceptions.InventoryAPIBadRequestException;
import com.project.InventoryManagementSystem.Repository.CustomerRepository;
import com.project.InventoryManagementSystem.Service.CustomerService;
import org.springframework.security.authentication.AuthenticationManager;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j 
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private AuthenticationManager authenticationManager;
    
    @Override
    public String registerCustomer(RegisterRequest request) {
        log.info("Registering a new customer with email: {}", request.getEmail());

        if (customerRepository.findByEmail(request.getEmail()).isPresent()) {
            log.error("Registration failed: Email {} already exists", request.getEmail());
            throw new InventoryAPIBadRequestException("Email already exists");
        }

        if (customerRepository.findByPhNo(request.getPhNo()).isPresent()) {
            log.error("Registration failed: Phone number {} already exists", request.getPhNo());
            throw new InventoryAPIBadRequestException("Phone number already exists");
        }

        Customer customer = new Customer();
        customer.setName(request.getName());
        customer.setEmail(request.getEmail());
        customer.setPhNo(request.getPhNo());
        customer.setPassword(passwordEncoder.encode(request.getPassword()));
        customer.setRole("CUSTOMER");
        customerRepository.save(customer);

        log.info("Customer registered successfully with email: {}", request.getEmail());
        return "Customer Registered successfully with ID: " + customer.getCustomerId();
    }

    @Override
    public String addAdmin(RegisterRequest request) {
        log.info("Adding a new admin with email: {}", request.getEmail());

        if (customerRepository.findByEmail(request.getEmail()).isPresent()) {
            log.error("Admin addition failed: Email {} already exists", request.getEmail());
            throw new InventoryAPIBadRequestException("Email already exists");
        }

        if (customerRepository.findByPhNo(request.getPhNo()).isPresent()) {
            log.error("Admin addition failed: Phone number {} already exists", request.getPhNo());
            throw new InventoryAPIBadRequestException("Phone number already exists");
        }

        Customer customer = new Customer();
        customer.setName(request.getName());
        customer.setEmail(request.getEmail());
        customer.setPhNo(request.getPhNo());
        customer.setPassword(passwordEncoder.encode(request.getPassword()));
        customer.setRole("ADMIN");
        customerRepository.save(customer);

        log.info("Admin added successfully with email: {}", request.getEmail());
        return "Admin added successfully with ID: " +customer.getCustomerId();
    }

    @Override
    public String CustomerOrAdminLogin(LoginRequest request) {
        log.info("Attempting login for user with email: {}", request.getEmail());

        Customer customer = customerRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> {
                    log.error("Login failed: User not found with email: {}", request.getEmail());
                    return new CustomerNotFoundException(
                            "User not found with the given email: " + request.getEmail());
                });

        if (!passwordEncoder.matches(request.getPassword(), customer.getPassword())) {
            log.error("Login failed: Invalid password for email: {}", request.getEmail());
            throw new InventoryAPIBadRequestException("Invalid password");
        }

        log.info("Password validation successful for user with email: {}", request.getEmail());

    
    log.info("Authenticating user with email: {}", request.getEmail());
    Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
    log.info("Authentication successful for user with email: {}", request.getEmail());

    SecurityContextHolder.getContext().setAuthentication(authentication);
    log.info("Security context updated for user with email: {}", request.getEmail());

    String token = jwtUtil.generateToken(authentication);
    log.info("JWT token generated successfully for user with email: {}", request.getEmail());

    return "Login successful. JWT Token: " + token;
    }

    @Override
public String updateCustomerDetails(long id, CustomerUpdateRequest request) {
    log.info("Updating Customer details with ID: {}", id);

    // Fetch the authenticated user's email from the SecurityContext
    String authenticatedEmail = SecurityContextHolder.getContext().getAuthentication().getName();
    log.info("Authenticated user email: {}", authenticatedEmail);

    // Fetch the customer by ID
    Customer customer = customerRepository.findById(id)
            .orElseThrow(() -> {
                log.error("Update failed: Customer with ID {} not found", id);
                return new CustomerNotFoundException("Customer with ID " + id + " not found");
            });

    // Check if the authenticated user is authorized to update this customer's details
    if (!customer.getEmail().equals(authenticatedEmail)) {
        log.error("Update failed: Authenticated user {} is not authorized to update details for customer with ID {}", authenticatedEmail, id);
        throw new InventoryAPIBadRequestException("You are not authorized to update this customer's details");
    }

    // Update customer details
    if (request.getName() != null) {
        log.info("Updating name for Customer with ID: {}", id);
        customer.setName(request.getName());
    }
    if (request.getPhNo() != null) {
        if (customerRepository.findByPhNo(request.getPhNo()).isPresent()) {
            log.error("Update failed: Phone number {} already exists", request.getPhNo());
            throw new InventoryAPIBadRequestException("Phone number already exists");
        }
        log.info("Updating phone number for user with ID: {}", id);
        customer.setPhNo(request.getPhNo());
    }

    customerRepository.save(customer);
    log.info("Customer details updated successfully for ID: {}", id);

    return "Customer details updated successfully";
}

@Override
public String updateAdminDetails(String email, CustomerUpdateRequest request) {
    log.info("Updating Admin details with Email : {}", email);

    // Fetch the authenticated user's email from the SecurityContext
    String authenticatedEmail = SecurityContextHolder.getContext().getAuthentication().getName();
    log.info("Authenticated admin email: {}", authenticatedEmail);

    // Fetch the admin by ID
    Customer customer = customerRepository.findByEmail(email)
            .orElseThrow(() -> {
                log.error("Update failed: Admin with Email {} not found", email);
                return new CustomerNotFoundException("Admin with Email " + email + " not found");
            });

    // Ensure the authenticated admin is authorized to update their own details
    if (!customer.getEmail().equals(authenticatedEmail)) {
        log.error("Update failed: Authenticated admin {} is not authorized to update details for admin with Email {}", authenticatedEmail, email);
        throw new InventoryAPIBadRequestException("You are not authorized to update this admin's details");
    }

    // Update admin details
    if (request.getName() != null) {
        log.info("Updating name for Admin with Email: {}", email);
        customer.setName(request.getName());
    }
    if (request.getPhNo() != null) {
        if (customerRepository.findByPhNo(request.getPhNo()).isPresent()) {
            log.error("Update failed: Phone number {} already exists", request.getPhNo());
            throw new InventoryAPIBadRequestException("Phone number already exists");
        }
        log.info("Updating phone number for Admin with Email: {}", email);
        customer.setPhNo(request.getPhNo());
    }

    customerRepository.save(customer);
    log.info("Admin details updated successfully for Email: {}", email);

    return "Admin details updated successfully";
}

    @Override
    public CustomerProfile getCustomerProfile(long id) {
        log.info("Fetching customer details for ID: {}", id);

        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Fetch failed: Customer with ID {} not found", id);
                    return new CustomerNotFoundException("User not found");
                });

        CustomerProfile customerProfile = modelMapper.map(customer, CustomerProfile.class);
        log.info("Customer details fetched successfully for ID: {}", id);

        return customerProfile;
    }

    @Override
    public CustomerProfile getAdminProfile(String email) {
        log.info("Fetching Admin details for ID: {}", email);

        Customer admin = customerRepository.findByEmail(email)
                .orElseThrow(() -> {
                    log.error("Fetch failed: Admin with Email {} not found", email);
                    return new CustomerNotFoundException("User not found");
                });

        CustomerProfile adminProfile = modelMapper.map(admin, CustomerProfile.class);
        log.info("Admin details fetched successfully for Email: {}", email);

        return adminProfile;
    }
    
    
    @Override
    public List<CustomerProfile> getAllCustomers() {
        log.info("Fetching all customers");
        
        List<Customer> customers = customerRepository.findAllCustomers();
        List<CustomerProfile> customerProfiles = customers.stream()
        .map(customer -> modelMapper.map(customer, CustomerProfile.class)).toList();
        
        log.info("Fetched all customers successfully");
        return customerProfiles;
        
    }

    @Override
    public CustomerProfile getCustomerProfileByEmail(String email) {
        log.info("Fetching customer details for email: {}", email);
       
        Customer customer = customerRepository.findByEmail(email)
                .orElseThrow(() -> {
                    log.error("Customer with email {} not found", email);
                    return new CustomerNotFoundException("Customer not found");
                });
       
        return modelMapper.map(customer, CustomerProfile.class);
    }
     
    @Override
    public String updateCustomerDetailsByEmail(String email, CustomerUpdateRequest request) {
        log.info("Updating customer details for email: {}", email);
       
        // Verify authenticated user matches the email being updated
        String authenticatedEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        if (!email.equals(authenticatedEmail)) {
            log.error("Update failed: Authenticated user {} cannot update {}", authenticatedEmail, email);
            throw new InventoryAPIBadRequestException("Unauthorized update attempt");
        }
       
        Customer customer = customerRepository.findByEmail(email)
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found"));
       
        if (request.getName() != null) {
            customer.setName(request.getName());
        }
        if (request.getPhNo() != null) {
            customer.setPhNo(request.getPhNo());
        }
       
        customerRepository.save(customer);
        return "Customer details updated successfully";
    }
     

        @Override
    public String deleteCustomerProfile(long id) {
        log.info("Deleting Customer with id: {}", id);
    
        // Fetch the authenticated user's email from the SecurityContext
        String authenticatedEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        log.info("Authenticated customer email: {}", authenticatedEmail);
    
        // Fetch the customer by ID
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Delete failed: Customer with id {} not found", id);
                    return new CustomerNotFoundException("Customer not found");
                });
    
        // Ensure the authenticated customer is deleting their own profile
        if (!customer.getEmail().equals(authenticatedEmail)) {
            log.error("Delete failed: Authenticated customer {} is not authorized to delete profile for customer with ID {}", authenticatedEmail, id);
            throw new InventoryAPIBadRequestException("You are not authorized to delete this customer's profile");
        }
    
        customerRepository.delete(customer);
        log.info("Customer deleted successfully with ID: {}", id);
    
        return "Customer deleted successfully";
    }

    
}