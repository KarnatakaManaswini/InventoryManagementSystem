package com.project.InventoryManagementSystem.Service.Impl;

import com.project.InventoryManagementSystem.DTO.ProductDto;
import com.project.InventoryManagementSystem.DTO.StockDto;
import com.project.InventoryManagementSystem.Entities.Product;
import com.project.InventoryManagementSystem.Entities.Stock;
import com.project.InventoryManagementSystem.Exceptions.ProductNotFoundException;
import com.project.InventoryManagementSystem.Repository.ProductRepository;
import com.project.InventoryManagementSystem.Repository.StockRepository;
import com.project.InventoryManagementSystem.Service.ProductService;

import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ProductServiceImpl implements ProductService {

    @Autowired
    private StockRepository stockRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ProductRepository productRepository;

    @Override
    public ProductDto addProduct(ProductDto productDto) {
        log.info("Adding a new product: {}", productDto.getName());
        Product product = modelMapper.map(productDto, Product.class);

        Stock stock = new Stock();
        stock.setProduct(product);
        stock.setQuantity(productDto.getStockLevel());
        stock.setReorderLevel(10);
        product.setStock(stock);

        stockRepository.save(stock);
        log.info("Stock saved for product: {}", productDto.getName());
        @SuppressWarnings("unused")
        StockDto stockDto = modelMapper.map(stock, StockDto.class);
        Product savedProduct = productRepository.save(product);
        log.info("Product added successfully with ID: {}", savedProduct.getProductId());

        return modelMapper.map(savedProduct, ProductDto.class);
    }

    @Override
    public ProductDto updateProduct(long id, ProductDto productDto) {
        log.info("Updating product with ID: {}", id);
        Product product = productRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Product with ID {} not found for update", id);
                    return new ProductNotFoundException("Product With ID " + id + " Not Found To Update");
                });

        product.setName(productDto.getName());
        product.setDescription(productDto.getDescription());
        product.setPrice(productDto.getPrice());
        product.setStockLevel(productDto.getStockLevel());
        
        Stock stock = product.getStock();
        stock.setQuantity(productDto.getStockLevel());
        stock.setReorderLevel(10);
        product.setStock(stock);
        stockRepository.save(stock);
        log.info("Stock saved for product: {}", productDto.getName());
        @SuppressWarnings("unused")
        StockDto stockDto = modelMapper.map(stock, StockDto.class);
        Product updatedProduct = productRepository.save(product);
        log.info("Product with ID {} updated successfully", id);

        return modelMapper.map(updatedProduct, ProductDto.class);
    }

    @Override
    public void deleteProduct(long id) {
        log.info("Deleting product with ID: {}", id);
        if (!productRepository.existsById(id)) {
            log.error("Product with ID {} not found for deletion", id);
            throw new ProductNotFoundException("Product With ID " + id + " Not Found To Delete");
        }
        productRepository.deleteById(id);
        log.info("Product with ID {} deleted successfully", id);
    }

    @Override
    public void deleteAllProducts() {
        log.info("Deleting all products");
        productRepository.deleteAll();
        log.info("All products deleted successfully");
    }

    @Override
    public List<ProductDto> getAllProducts() {
        log.info("Fetching all products");
        List<Product> products = productRepository.findAll();
        log.info("Total products fetched: {}", products.size());
        return products.stream()
                .map(product -> modelMapper.map(product, ProductDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public ProductDto getProductById(long id) {
        log.info("Fetching product with ID: {}", id);
        Product product = productRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Product with ID {} not found", id);
                    return new ProductNotFoundException("Product with ID " + id + " Not Found");
                });
        log.info("Product with ID {} fetched successfully", id);
        return modelMapper.map(product, ProductDto.class);
    }
}