package com.project.InventoryManagementSystem.Service;

import java.util.List;

import com.project.InventoryManagementSystem.DTO.NotificationDto;

public interface NotificationService {
    List<NotificationDto> getAllNotifications();
}
