package com.project.InventoryManagementSystem.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.InventoryManagementSystem.DTO.CustomerProfile;
import com.project.InventoryManagementSystem.DTO.CustomerUpdateRequest;
import com.project.InventoryManagementSystem.DTO.LoginRequest;
import com.project.InventoryManagementSystem.DTO.RegisterRequest;
import com.project.InventoryManagementSystem.Service.Impl.CustomerServiceImpl;
import org.springframework.web.bind.annotation.CrossOrigin;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/customers")   // maps reqs to handler methods
@CrossOrigin(origins = "http://localhost:3000")  //enables CORS,Front-end running on this localhost can access this controller
public class CustomerController {

	@Autowired
	private CustomerServiceImpl customerService;

	@PostMapping("/register")  // maps post req to register end point   
	                                                   //takes json body & converts into obj  (or) reqbody to obj
	public ResponseEntity<String> registerCustomer(@Valid @RequestBody RegisterRequest request) {
		String response = customerService.registerCustomer(request);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@PostMapping("/login")
	public ResponseEntity<String> CustomerOrAdminLogin(@Valid @RequestBody LoginRequest request) {
		String response = customerService.CustomerOrAdminLogin(request);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/addAdmin")
	public ResponseEntity<String> addAdmin(@Valid @RequestBody RegisterRequest request) {
		String response = customerService.addAdmin(request);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}


	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/adminProfile")                         // bind web param to method param , extracts query param form url
	public ResponseEntity<CustomerProfile> getAdminProfileByEmail(@RequestParam String email) {
		CustomerProfile admin = customerService.getAdminProfile(email);
		return new ResponseEntity<>(admin, HttpStatus.OK);
	}

	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/getAllCustomers")
	public ResponseEntity<List<CustomerProfile>> getAllCustomers() {
		List<CustomerProfile> customers = customerService.getAllCustomers();
		return ResponseEntity.ok(customers);
	}

	@GetMapping("/my-profile")
	@PreAuthorize("hasRole('CUSTOMER')")
	public ResponseEntity<CustomerProfile> getMyProfile() {
		String email = SecurityContextHolder.getContext().getAuthentication().getName();
		return ResponseEntity.ok(customerService.getCustomerProfileByEmail(email));
	}

	@PutMapping("/update-profile")
	@PreAuthorize("hasAnyRole('CUSTOMER','ADMIN')")
	public ResponseEntity<String> updateMyProfile(
			@RequestBody CustomerUpdateRequest request) {
		String email = SecurityContextHolder.getContext().getAuthentication().getName();
		return ResponseEntity.ok(customerService.updateCustomerDetailsByEmail(email, request));
	}

	// @PreAuthorize("hasAnyRole('CUSTOMER')")
	// @GetMapping("/profile/{id}")
	// public ResponseEntity<CustomerProfile> getCustomerProfile(@PathVariable long
	// id) {
	// CustomerProfile customer = customerService.getCustomerProfile(id);
	// return new ResponseEntity<>(customer, HttpStatus.OK);
	// }

	// @PreAuthorize("hasAnyRole('CUSTOMER')")
	// @DeleteMapping("/deleteProfile/{id}")
	// public ResponseEntity<String> deleteCustomerProfile(@PathVariable long id) {
	// String response = customerService.deleteCustomerProfile(id);
	// return new ResponseEntity<>(response, HttpStatus.OK);
	// }

	// @PreAuthorize("hasRole('CUSTOMER')")
	// @PutMapping("/updateCustomer/{id}")
	// public ResponseEntity<String> updateCustomerDetails(@PathVariable long id,
	// @Valid @RequestBody CustomerUpdateRequest request) {
	// String response = customerService.updateCustomerDetails(id, request);

	// return new ResponseEntity<>(response, HttpStatus.OK);
	// }
}