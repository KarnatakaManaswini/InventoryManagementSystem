package com.project.InventoryManagementSystem.Security;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import com.project.InventoryManagementSystem.Entities.Customer;
import com.project.InventoryManagementSystem.Repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;

@Service // cls is spring service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        Customer customer = customerRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Customer not found with email: " + email));

        // converting customer entity to a userDetails obj, setting username, pass & roles
        return User.withUsername(customer.getEmail()).password(customer.getPassword())
                .roles(customer.getRole()).build();
    }
}