package com.project.InventoryManagementSystem.Service.Impl;

import com.project.InventoryManagementSystem.DTO.NotificationDto;
import com.project.InventoryManagementSystem.Entities.Notification;
import com.project.InventoryManagementSystem.Repository.NotificationRepository;
import com.project.InventoryManagementSystem.Service.NotificationService;

import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j 
public class NotificationServiceImpl implements NotificationService{

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<NotificationDto> getAllNotifications() {
        log.info("Fetching all notifications");
        List<Notification> notifications = notificationRepository.findAll();
        log.info("Total notifications fetched: {}", notifications.size());
        return notifications.stream()
                .map(notification -> {
                    log.debug("Mapping notification with ID: {}", notification.getId());
                    return modelMapper.map(notification, NotificationDto.class);
                })
                .collect(Collectors.toList());
    }
}