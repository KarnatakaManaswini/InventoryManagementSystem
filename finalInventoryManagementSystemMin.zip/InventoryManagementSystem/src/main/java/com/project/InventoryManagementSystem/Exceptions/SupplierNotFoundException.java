package com.project.InventoryManagementSystem.Exceptions;

public class SupplierNotFoundException extends RuntimeException {
	public SupplierNotFoundException(String message) {
		super(message);
	}
}
