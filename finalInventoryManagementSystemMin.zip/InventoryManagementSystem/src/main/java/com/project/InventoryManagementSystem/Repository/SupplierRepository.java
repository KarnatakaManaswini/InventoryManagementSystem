package com.project.InventoryManagementSystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.InventoryManagementSystem.Entities.Supplier;

public interface SupplierRepository extends JpaRepository<Supplier, Integer> {

}
