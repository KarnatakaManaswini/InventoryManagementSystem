package com.project.InventoryManagementSystem.Service.Impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.InventoryManagementSystem.DTO.SupplierDto;
import com.project.InventoryManagementSystem.Entities.Supplier;
import com.project.InventoryManagementSystem.Exceptions.SupplierNotFoundException;
import com.project.InventoryManagementSystem.Repository.SupplierRepository;
import com.project.InventoryManagementSystem.Service.SupplierService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j 
public class SupplierServiceImpl implements SupplierService {

    @Autowired
    private SupplierRepository supplierRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public SupplierDto addSupplier(SupplierDto supplierDto) {
        log.info("Adding a new supplier with name: {}", supplierDto.getName());
        Supplier supplier = modelMapper.map(supplierDto, Supplier.class);
        Supplier saved = supplierRepository.save(supplier);
        log.info("Supplier added successfully with ID: {}", saved.getSupplierId());
        return modelMapper.map(saved, SupplierDto.class);
    }
    
    @Override
    public SupplierDto updateSupplier(int id, SupplierDto supplierDto) {
        log.info("Updating supplier with ID: {}", id);
        Supplier supplier = supplierRepository.findById(id)
        .orElseThrow(() -> {
            log.error("Supplier with ID {} not found for update", id);
            return new SupplierNotFoundException("Supplier With ID " + id + " Not Found To Update");
        });
        
        supplier.setName(supplierDto.getName());
        supplier.setContactInfo(supplierDto.getContactInfo());
        supplier.setProductsSupplied(supplierDto.getProductsSupplied());
        
        Supplier updatedSupplier = supplierRepository.save(supplier);
        log.info("Supplier with ID {} updated successfully", id);
        return modelMapper.map(updatedSupplier, SupplierDto.class);
    }
    
    @Override
    public void deleteSupplier(int id) {
        log.info("Deleting supplier with ID: {}", id);
        if (!supplierRepository.existsById(id)) {
            log.error("Supplier with ID {} not found for deletion", id);
            throw new SupplierNotFoundException("Supplier With ID " + id + " Not Found");
        }
        supplierRepository.deleteById(id);
        log.info("Supplier with ID {} deleted successfully", id);
    }
    
    @Override
    public void deleteAllSuppliers() {
        log.info("Deleting all suppliers");
        supplierRepository.deleteAll();
        log.info("All suppliers deleted successfully");
    }
    
    @Override
    public List<SupplierDto> getAllSuppliers() {
        log.info("Fetching all suppliers");
        List<Supplier> suppliers = supplierRepository.findAll();
        log.info("Total suppliers fetched: {}", suppliers.size());
        return suppliers.stream()
        .map(supplier -> modelMapper.map(supplier, SupplierDto.class))
        .collect(Collectors.toList());
    }
    
    @Override
    public SupplierDto getSupplierById(int id) {
        log.info("Fetching supplier with ID: {}", id);
        Supplier supplier = supplierRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Supplier with ID {} not found", id);
                    return new SupplierNotFoundException("Supplier With ID " + id + " Not Found");
                });
        log.info("Supplier with ID {} fetched successfully", id);
        return modelMapper.map(supplier, SupplierDto.class);
    }
}