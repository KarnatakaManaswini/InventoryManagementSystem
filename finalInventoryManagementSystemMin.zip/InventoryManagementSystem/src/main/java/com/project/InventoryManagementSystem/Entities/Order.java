package com.project.InventoryManagementSystem.Entities;
 
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.sql.Date;
 
import com.fasterxml.jackson.annotation.JsonBackReference;
 
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "orders")
public class Order {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long orderId;
 
    @NotNull(message = "Product cannot be null")
    @ManyToOne
    @JoinColumn(name = "productId", nullable = false)
    @JsonBackReference   //Prevents infinite recursion in bi-directional relationships during JSON serialization by ignoring the back-reference.
    private Product product;
 
    @NotNull(message = "Customer cannot be null")
    @ManyToOne
    @JoinColumn(name = "customerId", nullable = false)
    private Customer customer;
 
    @Min(value = 1, message = "Quantity must be at least 1")
    @Column(nullable = false)
    private int quantity;
 
    @NotNull(message = "Order date cannot be null")
    @Column(nullable = false)
    private Date orderdate;
 
    @NotNull(message = "Status cannot be null")
    @Enumerated(EnumType.STRING)  // enum vals will be stored as strings in dbs
    @Column(nullable = false)
    private Status status;
 
    public enum Status {
        Pending,
        Shipped,
        Delivered
    }
}