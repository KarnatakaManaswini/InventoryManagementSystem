package com.project.InventoryManagementSystem.Controllers;

import com.project.InventoryManagementSystem.DTO.NotificationDto;
import com.project.InventoryManagementSystem.Service.Impl.NotificationServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin(origins = "http://localhost:3000")
public class NotificationController {

    @Autowired
    private NotificationServiceImpl notificationService;

    @GetMapping("/getAll")
    public ResponseEntity<List<NotificationDto>> getAllNotifications() {
        List<NotificationDto> notifications = notificationService.getAllNotifications();
        return ResponseEntity.ok(notifications);
    }

}