package com.project.InventoryManagementSystem.DTO;

import lombok.Data;

@Data
public class CustomerProfile {
    private Long customerId;
    private String name;
    private String phNo;
    private String email;
}
