package com.project.InventoryManagementSystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.InventoryManagementSystem.Entities.Stock;

public interface StockRepository extends JpaRepository<Stock, Long> {

}
