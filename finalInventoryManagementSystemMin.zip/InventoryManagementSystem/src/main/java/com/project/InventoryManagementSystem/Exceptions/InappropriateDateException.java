package com.project.InventoryManagementSystem.Exceptions;

public class InappropriateDateException extends RuntimeException {
    public InappropriateDateException(String message) {
        super(message);
    }

}
