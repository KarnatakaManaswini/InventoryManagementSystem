package com.project.InventoryManagementSystem.Entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "stocks")
public class Stock {

    @Id
    private long productId;

    @Min(value = 0, message = "Quantity cannot be negative")
    @Column(nullable = false)
    private int quantity;

    @Min(value = 0, message = "Reorder level cannot be negative")
    @Column(nullable = false)
    private int reorderLevel;

    @OneToOne(fetch = FetchType.LAZY)
    @MapsId  // maps pkey or fkey as pkeys
    @JoinColumn(name = "productId")
    @JsonBackReference   //Prevents infinite recursion in bi-directional relationships during JSON serialization by ignoring the back-reference.
    private Product product;
}