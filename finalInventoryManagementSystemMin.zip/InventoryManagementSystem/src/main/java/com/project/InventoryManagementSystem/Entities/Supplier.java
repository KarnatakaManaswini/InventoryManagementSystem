package com.project.InventoryManagementSystem.Entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "suppliers")
public class Supplier {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int supplierId;

    @NotBlank(message = "Supplier name cannot be blank")
    @Column(nullable = false)
    private String name;

    @NotBlank(message = "Contact info cannot be blank")
    @Column(nullable = false)
    private String contactInfo;

    @NotEmpty(message = "Products supplied cannot be empty")
    @ElementCollection
    @Column(nullable = false)
    private List<String> productsSupplied;
}