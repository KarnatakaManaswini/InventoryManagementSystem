package com.project.InventoryManagementSystem.Service;

import java.util.List;

import com.project.InventoryManagementSystem.DTO.ProductDto;

public interface ProductService {
    ProductDto addProduct(ProductDto productDto);
    ProductDto updateProduct(long id, ProductDto productDto);
    void deleteAllProducts() ;
    List<ProductDto> getAllProducts();
    ProductDto getProductById(long id);
    void deleteProduct(long id);
}
