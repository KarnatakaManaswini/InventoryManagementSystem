package com.project.InventoryManagementSystem.Service.Impl;
 
import java.util.List;
import java.util.stream.Collectors;
 
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
 
import com.project.InventoryManagementSystem.DTO.OrderDto;
import com.project.InventoryManagementSystem.Entities.Customer;
import com.project.InventoryManagementSystem.Entities.Notification;
import com.project.InventoryManagementSystem.Entities.Order;
import com.project.InventoryManagementSystem.Entities.Order.Status;
import com.project.InventoryManagementSystem.Entities.Product;
import com.project.InventoryManagementSystem.Entities.Stock;
import com.project.InventoryManagementSystem.Exceptions.CustomerNotFoundException;
import com.project.InventoryManagementSystem.Exceptions.InsufficientStockException;
import com.project.InventoryManagementSystem.Exceptions.InventoryAPIBadRequestException;
import com.project.InventoryManagementSystem.Exceptions.OrderNotFoundException;
import com.project.InventoryManagementSystem.Exceptions.ProductNotFoundException;
import com.project.InventoryManagementSystem.Repository.CustomerRepository;
import com.project.InventoryManagementSystem.Repository.NotificationRepository;
import com.project.InventoryManagementSystem.Repository.OrderRepository;
import com.project.InventoryManagementSystem.Repository.ProductRepository;
import com.project.InventoryManagementSystem.Repository.StockRepository;
import com.project.InventoryManagementSystem.Service.OrderService;
 
import lombok.extern.slf4j.Slf4j;
 
import java.time.LocalDateTime;
import java.util.Date;
 
@Service
@Slf4j
public class OrderServiceImpl implements OrderService {
 
    @Autowired
    private OrderRepository orderRepository;
 
    @Autowired
    private ModelMapper modelMapper;
 
    @Autowired
    private CustomerRepository customerRepository;
 
    @Autowired
    private StockRepository stockRepository;
 
    @Autowired
    private StockServiceImpl stockService;
 
    @Autowired
    private NotificationRepository notificationRepository;
 
    @Autowired
    private ProductRepository productRepository;
   
 
    public void sendNotification(long productId, int quantity, int reorderLevel) {
        log.warn("Sending notification for Product ID: {}. Stock level: {}, Reorder level: {}", productId, quantity,
                reorderLevel);
 
 
            Product product = productRepository.findById(productId)
                .orElseThrow(() -> {
                    log.error("Product with ID {} not found", productId);
                    return new ProductNotFoundException("Product with ID " + productId + " not found");
                });
        String msg = "Admin Alert: Product " + product.getName()+
                " stock level (" + quantity + ") is below reorder level (" + reorderLevel + ").";
        Notification notification = new Notification();
        notification.setMessage(msg);
        notification.setDate(LocalDateTime.now());
        notificationRepository.save(notification);
 
        log.info("Notification saved for Product ID: {}", productId);
    }
 
    @Override
    public OrderDto placeOrder(String email, long productId, int quantity) {
        log.info("Placing order for customer with email: {}, product ID: {}, quantity: {}", email, productId, quantity);
 
        // Fetch the authenticated user's email from the SecurityContext
        String authenticatedEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        log.info("Authenticated customer email: {}", authenticatedEmail);
 
        // Ensure the authenticated customer is placing the order for themselves
        if (!email.equals(authenticatedEmail)) {
            log.error(
                    "Order placement failed: Authenticated customer {} is not authorized to place an order for email {}",
                    authenticatedEmail, email);
            throw new InventoryAPIBadRequestException("You are not authorized to place an order for this email");
        }
 
        // Fetch customer and product details
        Customer customer = customerRepository.findByEmail(email)
                .orElseThrow(() -> {
                    log.error("Customer with email {} not found", email);
                    return new CustomerNotFoundException("Customer with Email " + email + " not found");
                });
 
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> {
                    log.error("Product with ID {} not found", productId);
                    return new ProductNotFoundException("Product with ID " + productId + " not found");
                });
 
        // Check stock availability
        if (product.getStockLevel() < quantity) {
            log.error("Insufficient stock for product ID: {}. Requested: {}, Available: {}", productId, quantity,
                    product.getStockLevel());
            throw new InsufficientStockException("Insufficient stock");
        }
 
        // Update stock levels
        product.setStockLevel(product.getStockLevel() - quantity);
        productRepository.save(product);
        log.info("Stock level updated for product ID: {}. Remaining stock: {}", productId, product.getStockLevel());
        // Update stock repository
        Stock stock = stockRepository.findById(product.getProductId())
                .orElseThrow(() -> new ProductNotFoundException(
                        "Stock not found for product ID: " + product.getProductId()));
        stock.setQuantity(product.getStockLevel());
        stockRepository.save(stock);
        if (stock.getQuantity() < stock.getReorderLevel()) {
            log.warn("Stock level below reorder level for Product ID: {}. Sending notification.", productId);
            sendNotification(stock.getProductId(), stock.getQuantity(), stock.getReorderLevel());
        }
 
        // Create and save the order
        Order order = new Order();
        order.setCustomer(customer);
        order.setProduct(product);
        order.setQuantity(quantity);
        order.setOrderdate(new java.sql.Date(new Date().getTime()));
        order.setStatus(Status.Pending);
 
        Order savedOrder = orderRepository.save(order);
        log.info("Order placed successfully with ID: {}", savedOrder.getOrderId());
 
        return modelMapper.map(savedOrder, OrderDto.class);
    }
 
    @Override
    public OrderDto updateOrderStatus(long orderId, Status status) {
        log.info("Updating order status for order ID: {} to {}", orderId, status);
 
        // Fetch the authenticated user's role from the SecurityContext
        String authenticatedRole = SecurityContextHolder.getContext().getAuthentication().getAuthorities().toString();
        log.info("Authenticated user role: {}", authenticatedRole);
 
        // Ensure only admins can update order statuses
        if (!authenticatedRole.contains("ROLE_ADMIN")) {
            log.error("Update failed: Authenticated user is not authorized to update order statuses");
            throw new InventoryAPIBadRequestException("You are not authorized to update order statuses");
        }
 
        // Fetch and update the order
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> {
                    log.error("Order with ID {} not found", orderId);
                    return new OrderNotFoundException("Order not found");
                });
 
        order.setStatus(status);
        Order updatedOrder = orderRepository.save(order);
        log.info("Order status updated successfully for order ID: {}", orderId);
 
        return modelMapper.map(updatedOrder, OrderDto.class);
    }
 
    @Override
    public String deleteOrderById(long orderId) {
        log.info("Deleting order with ID: {}", orderId);
 
        // Fetch the order by ID
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> {
                    log.error("Order with ID {} not found", orderId);
                    return new OrderNotFoundException("Order not found with ID: " + orderId);
                });
 
        // Fetch the product associated with the order
        Product product = order.getProduct();
        if (product == null) {
            log.error("No product associated with order ID {}", orderId);
            throw new ProductNotFoundException("No product associated with this order");
        }
        // Update the product's stock level
        product.setStockLevel(product.getStockLevel() + order.getQuantity());
        productRepository.save(product);
        log.info("Stock level updated for product ID: {}. New stock level: {}", product.getProductId(),
                product.getStockLevel());
        // Update the stock repository
        Stock stock = stockRepository.findById(product.getProductId())
                .orElseThrow(() -> new ProductNotFoundException(
                        "Stock not found for product ID: " + product.getProductId()));
        stock.setQuantity(product.getStockLevel());
        stockRepository.save(stock);
 
        // Fetch the customer associated with the order
        Customer customer = order.getCustomer();
        if (customer == null) {
            log.error("No customer associated with order ID {}", orderId);
            throw new CustomerNotFoundException("No customer associated with this order");
        }
 
        orderRepository.delete(order);
        log.info("Order with ID {} deleted successfully", orderId);
 
        return "Order with ID " + orderId + " deleted successfully";
    }
 
    @Override
    public void deleteAllOrders() {
        log.info("Deleting all orders");
        orderRepository.deleteAll();
        log.info("All orders deleted successfully");
    }
 
    @Override
    public List<OrderDto> getAllOrders() {
        log.info("Fetching all orders");
        List<OrderDto> orders = orderRepository.findAll().stream()
                .map(order -> modelMapper.map(order, OrderDto.class))
                .collect(Collectors.toList());
        log.info("Total orders fetched: {}", orders.size());
        return orders;
    }
 
    // @Override
    // public OrderDto getOrderById(long orderId, String customerEmail) {
    // log.info("Fetching order with ID: {} for customer with email: {}", orderId,
    // customerEmail);
 
    // Customer customer = customerRepository.findByEmail(customerEmail)
    // .orElseThrow(() -> {
    // log.error("Customer with email {} not found", customerEmail);
    // return new CustomerNotFoundException("No customer found with email: " +
    // customerEmail);
    // });
 
    // Order order = orderRepository.findById(orderId)
    // .orElseThrow(() -> {
    // log.error("Order with ID {} not found", orderId);
    // return new OrderNotFoundException("Order not found with ID: " + orderId);
    // });
 
    // if (customer.getCustomerId() != order.getCustomer().getCustomerId()) {
    // log.error("Customer with email {} does not have order with ID {}",
    // customerEmail, orderId);
    // throw new OrderNotFoundException("Customer with email: " + customerEmail + "
    // does not have order with ID: " + orderId);
    // }
 
    // log.info("Order with ID {} fetched successfully for customer with email: {}",
    // orderId, customerEmail);
    // return modelMapper.map(order, OrderDto.class);
    // }
 
    @Override
    public OrderDto getOrderById(long orderId) {
        log.info("Fetching order with ID: {}", orderId);
 
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> {
                    log.error("Order with ID {} not found", orderId);
                    return new OrderNotFoundException("Order not found with ID: " + orderId);
                });
 
        log.info("Order with ID {} fetched successfully", orderId);
        return modelMapper.map(order, OrderDto.class);
    }
 
    @Override
    public List<OrderDto> getOrderByProductName(String name) {
        log.info("Fetching orders by product name: {}", name);
 
        List<Order> orders = orderRepository.findByProductName(name);
        if (orders.isEmpty()) {
            log.error("No orders found for product name: {}", name);
            throw new OrderNotFoundException("No orders found for product name: " + name);
        }
 
        log.info("Orders fetched successfully for product name: {}", name);
        return orders.stream()
                .map(order -> modelMapper.map(order, OrderDto.class))
                .toList();
    }
 
    @Override
    public List<OrderDto> getOrdersByCustomerId(Long customerId) {
        log.info("Fetching all orders for customer ID: {}", customerId);
 
        List<Order> orders = orderRepository.findByCustomerCustomerId(customerId);
        if (orders.isEmpty()) {
            log.warn("No orders found for customer ID: {}", customerId);
            throw new OrderNotFoundException("No orders found for customer ID: " + customerId);
        }
 
        List<OrderDto> orderDtos = orders.stream()
                .map(order -> modelMapper.map(order, OrderDto.class))
                .collect(Collectors.toList());
 
        log.info("Fetched {} orders for customer ID: {}", orderDtos.size(), customerId);
        return orderDtos;
    }
 
}