package com.project.InventoryManagementSystem.Controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.project.InventoryManagementSystem.DTO.SupplierDto;
import com.project.InventoryManagementSystem.Service.Impl.SupplierServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/suppliers")
@CrossOrigin(origins = "http://localhost:3000")
public class SupplierController {

	@Autowired
	private SupplierServiceImpl supplierService;

	@PostMapping("/add")
	public ResponseEntity<SupplierDto> addSupplier(@RequestBody @Valid SupplierDto supplierDto) {
		SupplierDto savedSupplier = supplierService.addSupplier(supplierDto);
		return ResponseEntity.ok(savedSupplier);
	}

	@PutMapping("/update/{supplierId}")
	public ResponseEntity<SupplierDto> updateSupplier(@PathVariable("supplierId") int id,
			@Valid @RequestBody SupplierDto supplierDto) {
		SupplierDto updateSupplier = supplierService.updateSupplier(id, supplierDto);
		return ResponseEntity.ok(updateSupplier);
	}

	@DeleteMapping("/deleteById/{supplierId}")
	public ResponseEntity<String> deleteSupplier(@PathVariable("supplierId") int id) {
		supplierService.deleteSupplier(id);
		return ResponseEntity.ok("Supplier with Id" + id + "removed successfully");
	}

	@DeleteMapping("/deleteAll")
	public ResponseEntity<String> deleteAllSuppliers() {
		supplierService.deleteAllSuppliers();
		return ResponseEntity.ok("All Suppliers removed successfully");
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<SupplierDto>> getAllSuppliers() {
		List<SupplierDto> supplierDto = supplierService.getAllSuppliers();
		return ResponseEntity.ok(supplierDto);
	}

	@GetMapping("/getById/{supplierId}")
	public ResponseEntity<SupplierDto> getSupplierById(@PathVariable("supplierId") int id) {
		SupplierDto supplierDto = supplierService.getSupplierById(id);
		return ResponseEntity.ok(supplierDto);
	}
}
