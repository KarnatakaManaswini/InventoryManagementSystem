package com.project.InventoryManagementSystem.Service;

import java.util.List;

import com.project.InventoryManagementSystem.DTO.StockDto;

public interface StockService {
    void sendNotification(long productId, int quantity, int reorderLevel);
    StockDto updateStockAndProductLevel(long productId, int newQuantity, StockDto stockDto);
    StockDto getStockById(long productId);
    List<StockDto> getAllStock();
}
