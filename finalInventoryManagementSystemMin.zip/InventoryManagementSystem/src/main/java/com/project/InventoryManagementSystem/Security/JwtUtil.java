package com.project.InventoryManagementSystem.Security;

import io.jsonwebtoken.ExpiredJwtException;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import java.security.Key;
import java.util.Date;
import javax.crypto.SecretKey;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.project.InventoryManagementSystem.Exceptions.InventoryAPIBadRequestException;

@Component // spring component , eligible for compoent scanning & dependency injection
public class JwtUtil { //generates, validates, extracts info from jwt tokens

    @Value("${jwt-secret}") // injects val from app.properties
    private String jwtSecret;  // secret key to sign jwt

    @Value("${jwt-expiration-milliseconds}")
    private long jwtExpirationDate;

    private Key key() {  //decodes secret key using Base64 & return key obj to sign jwt 
        return Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
    }

    //generates token using user mail & role
    public String generateToken(Authentication authentication) {

        String email = authentication.getName();
        return Jwts.builder()
                .subject(email)
                .claim("roles", authentication.getAuthorities())
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + jwtExpirationDate))
                .signWith(key())
                .compact();
    }

    public String extractEmail(String token) {
        return Jwts.parser()
                .verifyWith((SecretKey) key())
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .getSubject();
    }

    public boolean validateToken(String token) {
        try {
            Jwts.parser()
                    .verifyWith((SecretKey) key())
                    .build()
                    .parse(token);
            return true;
        } catch (MalformedJwtException malformedJwtException) {
            throw new InventoryAPIBadRequestException("Invalid JWT Token");
        } catch (ExpiredJwtException expiredJwtException) {
            throw new InventoryAPIBadRequestException("Expired JWT token");
        } catch (UnsupportedJwtException unsupportedJwtException) {
            throw new InventoryAPIBadRequestException("Unsupported JWT token");
        } catch (IllegalArgumentException illegalArgumentException) {
            throw new InventoryAPIBadRequestException("Jwt claims string is null or empty");
        }
    }
}
