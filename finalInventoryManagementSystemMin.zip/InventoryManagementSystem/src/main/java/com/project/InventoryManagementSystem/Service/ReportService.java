package com.project.InventoryManagementSystem.Service;

import java.time.LocalDate;
import java.util.List;

import com.project.InventoryManagementSystem.DTO.ReportDto;
import com.project.InventoryManagementSystem.Entities.Report.ReportType;

public interface ReportService {
    String create(ReportDto reportDto);
    ReportDto getReportById(long id);
    List<ReportDto> findAllReports();
    void deleteById(long id);
    void updateData(long id, ReportDto reportDto);
    List<ReportDto> getReportByReportType(ReportType reportType);
    List<ReportDto> getReportByDate(LocalDate startDate, LocalDate endDate);
}
