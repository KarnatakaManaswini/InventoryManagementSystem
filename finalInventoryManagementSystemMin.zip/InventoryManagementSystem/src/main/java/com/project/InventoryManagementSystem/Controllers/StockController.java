package com.project.InventoryManagementSystem.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.project.InventoryManagementSystem.DTO.StockDto;
import com.project.InventoryManagementSystem.Service.Impl.StockServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/stocks")
@CrossOrigin(origins = "http://localhost:3000")
public class StockController {

    @Autowired
    private StockServiceImpl stockService;

    @PutMapping("/update/{productId}")
    public ResponseEntity<StockDto> updateStockAndProductLevel(@PathVariable long productId,
            @RequestParam int newQuantity, @RequestBody @Valid StockDto stockDTO) {
        stockDTO.setProductId(productId);
        StockDto updated = stockService.updateStockAndProductLevel(productId, newQuantity, stockDTO);
        return ResponseEntity.ok(updated);
    }

    @GetMapping("/getStockById/{productId}")
    public ResponseEntity<StockDto> getStockById(@PathVariable long productId) {
        StockDto stockDto = stockService.getStockById(productId);
        return ResponseEntity.ok(stockDto);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<StockDto>> getAllStock() {
        List<StockDto> stocks = stockService.getAllStock();
        return ResponseEntity.ok(stocks);
    }
}