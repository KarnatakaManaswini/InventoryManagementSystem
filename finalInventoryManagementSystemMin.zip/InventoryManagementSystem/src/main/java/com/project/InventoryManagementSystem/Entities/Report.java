package com.project.InventoryManagementSystem.Entities;
 
import java.time.LocalDate;
 
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "reports")
public class Report {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long reportId;
 
    @Enumerated(EnumType.STRING)
    @NotNull(message = "Report type cannot be null")
    private ReportType reportType;
 
     @NotNull(message = "Start date cannot be null")
    @PastOrPresent(message = "Start date must be in the past or today")
    private LocalDate startDate;
 
    @NotNull(message = "End date cannot be null")
    @PastOrPresent(message = "End date must be in the past or today")
    private LocalDate endDate;
 
    @AssertTrue(message = "End date must not be earlier than start date")
    public boolean isEndDateValid() {
        if (startDate == null || endDate == null) {
            return true; // Skip validation if either date is null (handled by @NotNull)
        }
        return !endDate.isBefore(startDate);
    }
 
    @NotBlank(message = "Data cannot be blank")
    @Size(min = 5, message = "Data must be at least 5 characters long")
    private String data;
 
    public enum ReportType {
        Inventory, Supplier, Order
    }
}
 