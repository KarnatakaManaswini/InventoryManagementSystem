package com.project.InventoryManagementSystem.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.project.InventoryManagementSystem.Entities.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
	Optional<Customer> findByEmail(String email);

	Optional<Customer> findById(long id);

	Optional<Customer> findByPhNo(String phNo);

	@Query("SELECT c FROM Customer c WHERE c.role = 'CUSTOMER'")
    List<Customer> findAllCustomers();
}
