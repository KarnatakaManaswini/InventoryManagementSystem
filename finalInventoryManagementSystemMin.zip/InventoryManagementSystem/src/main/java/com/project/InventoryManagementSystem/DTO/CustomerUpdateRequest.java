package com.project.InventoryManagementSystem.DTO;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CustomerUpdateRequest {

    @Email(message = "Invalid email format")  // ensures it has valid email format
    @NotBlank(message = "Email is required")
    private String email;

    @NotBlank(message = "Name is required")
    private String name;
                                      //Validates field against reg exp.
    @Pattern(regexp = "^\\d{10}$", message = "Phone number must be 10 digits")
    private String phNo;
}








//^[1-9]\\d{10}$