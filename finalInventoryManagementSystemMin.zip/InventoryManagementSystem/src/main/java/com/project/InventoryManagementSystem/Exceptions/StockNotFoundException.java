package com.project.InventoryManagementSystem.Exceptions;

public class StockNotFoundException extends RuntimeException {
	public StockNotFoundException(String message) {
		super(message);
	}

}
