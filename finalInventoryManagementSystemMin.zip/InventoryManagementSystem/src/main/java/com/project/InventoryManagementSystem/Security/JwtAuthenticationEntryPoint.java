package com.project.InventoryManagementSystem.Security;

import java.io.IOException;

import org.springframework.security.core.AuthenticationException;

import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component        //handles unauthorized access attempts.
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {

    @Override      //sends 401 unauthorized response when unauthenticated user tries to access a secured endpoints
    public void commence(HttpServletRequest request,
            HttpServletResponse response,
            AuthenticationException authException) throws IOException, ServletException {

        response.sendError(HttpServletResponse.SC_UNAUTHORIZED, authException.getMessage());
    }
}
