package com.project.InventoryManagementSystem.DTO;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.sql.Date;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class OrderDto {

    private long orderId;

    @NotNull(message = "Product ID cannot be null")
    private long productId;

    @NotNull(message = "Customer ID cannot be null")
    private long customerId;

    @Min(value = 1, message = "Quantity must be at least 1")
    private int quantity;

    @NotNull(message = "Order date cannot be null")
    private Date orderdate;

    @NotNull(message = "Status cannot be null")
    private Status status;

    public enum Status {
        Pending,
        Shipped,
        Delivered
    }
    
    //data type that represents grp of constants.The constants represents category/type
}