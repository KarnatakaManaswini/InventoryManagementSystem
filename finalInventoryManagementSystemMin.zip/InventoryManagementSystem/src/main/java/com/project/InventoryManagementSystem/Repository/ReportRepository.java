package com.project.InventoryManagementSystem.Repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.InventoryManagementSystem.Entities.Report;
import com.project.InventoryManagementSystem.Entities.Report.ReportType;

@Repository
public interface ReportRepository extends JpaRepository<Report, Long> {

	public List<Report> findByReportType(ReportType reportType);// find by report type
	public List<Report> findByStartDateBetween(LocalDate startDate, LocalDate endDate);

}
