package com.project.InventoryManagementSystem.Service;

import java.util.List;

import com.project.InventoryManagementSystem.DTO.CustomerProfile;
import com.project.InventoryManagementSystem.DTO.CustomerUpdateRequest;
import com.project.InventoryManagementSystem.DTO.LoginRequest;
import com.project.InventoryManagementSystem.DTO.RegisterRequest;

public interface CustomerService {
    String registerCustomer(RegisterRequest request);
    
    String addAdmin(RegisterRequest request);
    
    CustomerProfile getCustomerProfile(long id);
    
    CustomerProfile getAdminProfile(String email);
    
    List<CustomerProfile> getAllCustomers();
    
    String updateCustomerDetails(long id, CustomerUpdateRequest request);
    
    String updateAdminDetails(String email, CustomerUpdateRequest request);
    
    String CustomerOrAdminLogin(LoginRequest request);
    
    String deleteCustomerProfile(long id);
    
    CustomerProfile getCustomerProfileByEmail(String email);
    
    String updateCustomerDetailsByEmail(String email, CustomerUpdateRequest request);
}