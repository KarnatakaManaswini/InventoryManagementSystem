package com.project.InventoryManagementSystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.InventoryManagementSystem.Entities.Notification;

public interface NotificationRepository extends JpaRepository<Notification, Integer> {

}
