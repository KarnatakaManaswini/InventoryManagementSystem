package com.project.InventoryManagementSystem.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.project.InventoryManagementSystem.DTO.OrderDto;
import com.project.InventoryManagementSystem.Service.OrderService;
import com.project.InventoryManagementSystem.Entities.Order.Status;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "http://localhost:3000")
public class OrderController {

	@Autowired
	private OrderService orderService;

	@PreAuthorize("hasRole('CUSTOMER')")
	@PostMapping("/placeOrder")
	public ResponseEntity<String> placeOrder(@RequestParam String email,
			@RequestParam long productId, @RequestParam int quantity) {
		OrderDto order = orderService.placeOrder(email, productId, quantity);
		return ResponseEntity.ok("Order placed successfully with Order Id: " + order.getOrderId());
	}

	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/updateStatus/{orderId}")
	public ResponseEntity<OrderDto> updateOrderStatus(@PathVariable long orderId, @RequestParam Status status) {
		OrderDto updatedOrder = orderService.updateOrderStatus(orderId, status);
		return ResponseEntity.ok(updatedOrder);
	}

	@PreAuthorize("hasRole('CUSTOMER')")
	@DeleteMapping("/deleteById/{orderId}")
	public ResponseEntity<String> deleteOrderById(@PathVariable long orderId) {
		String response = orderService.deleteOrderById(orderId);
		return ResponseEntity.ok(response);
	}

	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/deleteAll")
	public ResponseEntity<String> deleteAllOrders() {
		orderService.deleteAllOrders();
		return ResponseEntity.ok("All orders removed successfully");
	}

	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/getAllOrders")
	public ResponseEntity<List<OrderDto>> getAllOrders() {
		return ResponseEntity.ok(orderService.getAllOrders());
	}

	@PreAuthorize("hasAnyRole('ADMIN','CUSTOMER')")
	@GetMapping("/getOrderById/{orderId}")
	public ResponseEntity<OrderDto> getOrderById(@PathVariable long orderId) {
		OrderDto order = orderService.getOrderById(orderId);
		return ResponseEntity.ok(order);
	}

	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/getOrderByProductName")
	public ResponseEntity<List<OrderDto>> getOrderByProductName(@RequestParam String name) {
		return new ResponseEntity<>(orderService.getOrderByProductName(name), HttpStatus.OK);
	}

	@PreAuthorize("hasRole('CUSTOMER')")
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<OrderDto>> getOrdersByCustomerId(@PathVariable Long customerId) {
        List<OrderDto> orders = orderService.getOrdersByCustomerId(customerId);
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

}
