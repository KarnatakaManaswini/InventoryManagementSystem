package com.project.InventoryManagementSystem.DTO;
 
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
import java.time.LocalDate;
 
import com.project.InventoryManagementSystem.Entities.Report.ReportType;
 
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ReportDto {
 
    private long reportId;
 
    @NotNull(message = "Report type cannot be null")
    private ReportType reportType;
 
    @NotNull(message = "Start date cannot be null")
     @PastOrPresent(message = "Start date must be in the past or today")
    private LocalDate startDate;
 
    @NotNull(message = "End date cannot be null")
    @PastOrPresent(message = "End date must be in the past or today")
    private LocalDate endDate;
 
             // ensures method return true , if false validation fails
    @AssertTrue(message = "End date must not be earlier than start date")
    public boolean isEndDateValid() {
        if (startDate == null || endDate == null) {
            return true; // Skip validation if either date is null (handled by @NotNull)
        }
        return !endDate.isBefore(startDate);
    }
 
    @NotBlank(message = "Data cannot be blank")
    @Size(min = 5, message = "Data must be at least 5 characters long")
    private String data;
}