package com.project.InventoryManagementSystem.Exceptions;

import java.time.LocalDateTime;

public class ErrorDetails {
	private LocalDateTime timestamp;
	private String message;
	private String path;
	public ErrorDetails(LocalDateTime timestamp, String message, String path) {
		this.timestamp = timestamp;
		this.message = message;
		this.path = path;
	}

	// Getters and Setters
	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

}
