package com.project.InventoryManagementSystem.Service;

import java.util.List;

import com.project.InventoryManagementSystem.DTO.SupplierDto;

public interface SupplierService {
     SupplierDto addSupplier(SupplierDto supplierDto);
     SupplierDto updateSupplier(int id, SupplierDto supplierDto);
        void deleteSupplier(int id);
        void deleteAllSuppliers();
        List<SupplierDto> getAllSuppliers();
        SupplierDto getSupplierById(int id);
}
