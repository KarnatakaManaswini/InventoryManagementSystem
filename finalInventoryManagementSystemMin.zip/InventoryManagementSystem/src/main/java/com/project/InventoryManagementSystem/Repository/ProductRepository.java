package com.project.InventoryManagementSystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.InventoryManagementSystem.Entities.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {

}
