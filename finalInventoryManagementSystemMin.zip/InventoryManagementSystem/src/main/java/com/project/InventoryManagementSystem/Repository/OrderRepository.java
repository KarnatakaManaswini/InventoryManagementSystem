package com.project.InventoryManagementSystem.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.query.Param;

import com.project.InventoryManagementSystem.Entities.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByProductName(@Param("name") String name);
    List<Order> findByCustomerCustomerId(Long customerId);
}
