package com.project.InventoryManagementSystem.ServicesTest;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.project.InventoryManagementSystem.DTO.StockDto;
import com.project.InventoryManagementSystem.Entities.Notification;
import com.project.InventoryManagementSystem.Entities.Product;
import com.project.InventoryManagementSystem.Entities.Stock;
import com.project.InventoryManagementSystem.Repository.NotificationRepository;
import com.project.InventoryManagementSystem.Repository.ProductRepository;
import com.project.InventoryManagementSystem.Repository.StockRepository;
import com.project.InventoryManagementSystem.Service.Impl.StockServiceImpl;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class StockServiceImplTest {

    @Mock
    private NotificationRepository notificationRepository;

    @Mock
    private StockRepository stockRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private org.modelmapper.ModelMapper modelMapper;

    @InjectMocks
    private StockServiceImpl stockService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSendNotification() {

        long productId = 1L;
        int quantity = 5;
        int reorderLevel = 10;

        Notification notification = new Notification();
        notification.setMessage("Admin Alert: Product ID " + productId +
                " stock level (" + quantity + ") is below reorder level (" + reorderLevel + ").");
        notification.setDate(LocalDateTime.now());

        when(notificationRepository.save(any(Notification.class))).thenReturn(notification);

        stockService.sendNotification(productId, quantity, reorderLevel);

        verify(notificationRepository, times(1)).save(any(Notification.class));
    }

    @Test
    void testUpdateStockAndProductLevel() {
        long productId = 1L;
        int newQuantity = 20;

        Stock stock = new Stock();
        stock.setProductId(productId);
        stock.setQuantity(30);
        stock.setReorderLevel(50);

        StockDto stockDto = new StockDto();
        stockDto.setProductId(productId);
        stockDto.setReorderLevel(50);

        StockDto updatedStockDto = new StockDto();
        updatedStockDto.setProductId(productId);
        updatedStockDto.setQuantity(50);

        Product product = new Product();
        product.setProductId(productId);
        product.setStockLevel(30);

        when(stockRepository.findById(productId)).thenReturn(Optional.of(stock));
        when(modelMapper.map(stock, StockDto.class)).thenReturn(updatedStockDto);
        when(productRepository.findById(productId)).thenReturn(Optional.of(product));

        StockDto result = stockService.updateStockAndProductLevel(productId, newQuantity, stockDto);

        assertNotNull(result);
        assertEquals(50, result.getQuantity());
        verify(stockRepository, times(1)).save(any(Stock.class));
        verify(productRepository, times(1)).save(any(Product.class));
    }

    @Test
    void testGetStockById() {
        long productId = 1L;
        Stock stock = new Stock();
        stock.setProductId(productId);
        stock.setQuantity(100);

        StockDto stockDto = new StockDto();
        stockDto.setQuantity(100);

        when(stockRepository.findById(productId)).thenReturn(Optional.of(stock));
        when(modelMapper.map(stock, StockDto.class)).thenReturn(stockDto);

        StockDto result = stockService.getStockById(productId);

        assertNotNull(result);
        assertEquals(100, result.getQuantity());
    }

    @Test
    void testGetAllStock() {
        Stock stock1 = new Stock();
        stock1.setProductId(1L);
        stock1.setQuantity(100);

        Stock stock2 = new Stock();
        stock2.setProductId(2L);
        stock2.setQuantity(50);

        StockDto stockDto1 = new StockDto();
        stockDto1.setQuantity(100);

        StockDto stockDto2 = new StockDto();
        stockDto2.setQuantity(50);

        when(stockRepository.findAll()).thenReturn(Arrays.asList(stock1, stock2));
        when(modelMapper.map(stock1, StockDto.class)).thenReturn(stockDto1);
        when(modelMapper.map(stock2, StockDto.class)).thenReturn(stockDto2);

        List<StockDto> result = stockService.getAllStock();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(100, result.get(0).getQuantity());
        assertEquals(50, result.get(1).getQuantity());
    }
}