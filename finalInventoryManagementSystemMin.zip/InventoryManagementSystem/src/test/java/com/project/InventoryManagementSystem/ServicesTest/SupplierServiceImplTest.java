package com.project.InventoryManagementSystem.ServicesTest;

import com.project.InventoryManagementSystem.DTO.SupplierDto;
import com.project.InventoryManagementSystem.Entities.Supplier;
import com.project.InventoryManagementSystem.Exceptions.SupplierNotFoundException;
import com.project.InventoryManagementSystem.Repository.SupplierRepository;
import com.project.InventoryManagementSystem.Service.Impl.SupplierServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SupplierServiceImplTest {

    @Mock
    private SupplierRepository supplierRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private SupplierServiceImpl supplierService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddSupplier() {

        SupplierDto supplierDto = new SupplierDto();
        supplierDto.setName("Test Supplier");

        Supplier supplier = new Supplier();
        supplier.setName("Test Supplier");

        Supplier savedSupplier = new Supplier();
        savedSupplier.setSupplierId(1);
        savedSupplier.setName("Test Supplier");

        when(modelMapper.map(supplierDto, Supplier.class)).thenReturn(supplier);
        when(supplierRepository.save(supplier)).thenReturn(savedSupplier);
        when(modelMapper.map(savedSupplier, SupplierDto.class)).thenReturn(supplierDto);

        SupplierDto result = supplierService.addSupplier(supplierDto);

        assertNotNull(result);
        assertEquals("Test Supplier", result.getName());
        verify(supplierRepository, times(1)).save(supplier);
    }

    @Test
    void testUpdateSupplier_Success() {

        int supplierId = 1;
        SupplierDto supplierDto = new SupplierDto();
        supplierDto.setName("Updated Supplier");

        Supplier existingSupplier = new Supplier();
        existingSupplier.setSupplierId(supplierId);
        existingSupplier.setName("Old Supplier");

        Supplier updatedSupplier = new Supplier();
        updatedSupplier.setSupplierId(supplierId);
        updatedSupplier.setName("Updated Supplier");

        when(supplierRepository.findById(supplierId)).thenReturn(Optional.of(existingSupplier));
        when(supplierRepository.save(existingSupplier)).thenReturn(updatedSupplier);
        when(modelMapper.map(updatedSupplier, SupplierDto.class)).thenReturn(supplierDto);

        SupplierDto result = supplierService.updateSupplier(supplierId, supplierDto);

        assertNotNull(result);
        assertEquals("Updated Supplier", result.getName());
        verify(supplierRepository, times(1)).findById(supplierId);
        verify(supplierRepository, times(1)).save(existingSupplier);
    }

    @Test
    void testUpdateSupplier_NotFound() {

        int supplierId = 1;
        SupplierDto supplierDto = new SupplierDto();
        when(supplierRepository.findById(supplierId)).thenReturn(Optional.empty());

        assertThrows(SupplierNotFoundException.class, () -> supplierService.updateSupplier(supplierId, supplierDto));
        verify(supplierRepository, times(1)).findById(supplierId);
    }

    @Test
    void testDeleteSupplier_Success() {

        int supplierId = 1;
        when(supplierRepository.existsById(supplierId)).thenReturn(true);

        supplierService.deleteSupplier(supplierId);

        verify(supplierRepository, times(1)).existsById(supplierId);
        verify(supplierRepository, times(1)).deleteById(supplierId);
    }

    @Test
    void testDeleteSupplier_NotFound() {

        int supplierId = 1;
        when(supplierRepository.existsById(supplierId)).thenReturn(false);

        assertThrows(SupplierNotFoundException.class, () -> supplierService.deleteSupplier(supplierId));
        verify(supplierRepository, times(1)).existsById(supplierId);
    }

    @Test
    void testDeleteAllSuppliers() {

        supplierService.deleteAllSuppliers();

        verify(supplierRepository, times(1)).deleteAll();
    }

    @Test
    void testGetAllSuppliers() {

        Supplier supplier1 = new Supplier();
        supplier1.setName("Supplier 1");

        Supplier supplier2 = new Supplier();
        supplier2.setName("Supplier 2");

        List<Supplier> suppliers = Arrays.asList(supplier1, supplier2);

        SupplierDto supplierDto1 = new SupplierDto();
        supplierDto1.setName("Supplier 1");

        SupplierDto supplierDto2 = new SupplierDto();
        supplierDto2.setName("Supplier 2");

        when(supplierRepository.findAll()).thenReturn(suppliers);
        when(modelMapper.map(supplier1, SupplierDto.class)).thenReturn(supplierDto1);
        when(modelMapper.map(supplier2, SupplierDto.class)).thenReturn(supplierDto2);

        List<SupplierDto> result = supplierService.getAllSuppliers();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Supplier 1", result.get(0).getName());
        assertEquals("Supplier 2", result.get(1).getName());
        verify(supplierRepository, times(1)).findAll();
    }

    @Test
    void testGetSupplierById_Success() {

        int supplierId = 1;
        Supplier supplier = new Supplier();
        supplier.setSupplierId(supplierId);
        supplier.setName("Test Supplier");

        SupplierDto supplierDto = new SupplierDto();
        supplierDto.setName("Test Supplier");

        when(supplierRepository.findById(supplierId)).thenReturn(Optional.of(supplier));
        when(modelMapper.map(supplier, SupplierDto.class)).thenReturn(supplierDto);

        SupplierDto result = supplierService.getSupplierById(supplierId);

        assertNotNull(result);
        assertEquals("Test Supplier", result.getName());
        verify(supplierRepository, times(1)).findById(supplierId);
    }

    @Test
    void testGetSupplierById_NotFound() {

        int supplierId = 1;
        when(supplierRepository.findById(supplierId)).thenReturn(Optional.empty());

        assertThrows(SupplierNotFoundException.class, () -> supplierService.getSupplierById(supplierId));
        verify(supplierRepository, times(1)).findById(supplierId);
    }
}