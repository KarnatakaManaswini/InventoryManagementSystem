package com.project.InventoryManagementSystem.ServicesTest;

import com.project.InventoryManagementSystem.DTO.CustomerProfile;
import com.project.InventoryManagementSystem.DTO.LoginRequest;
import com.project.InventoryManagementSystem.DTO.RegisterRequest;
import com.project.InventoryManagementSystem.Entities.Customer;
import com.project.InventoryManagementSystem.Exceptions.CustomerNotFoundException;
import com.project.InventoryManagementSystem.Exceptions.InventoryAPIBadRequestException;
import com.project.InventoryManagementSystem.Repository.CustomerRepository;
import com.project.InventoryManagementSystem.Service.Impl.CustomerServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CustomerServiceImplTest {

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private ModelMapper modelMapper;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private CustomerServiceImpl customerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterCustomer_EmailAlreadyExists() {
        RegisterRequest request = new RegisterRequest();
        request.setEmail("test@example.com");

        when(customerRepository.findByEmail(request.getEmail())).thenReturn(Optional.of(new Customer()));

        assertThrows(InventoryAPIBadRequestException.class, () -> customerService.registerCustomer(request));
        verify(customerRepository, times(1)).findByEmail(request.getEmail());
    }

    @Test
    void testCustomerOrAdminLogin_Success() {
        LoginRequest request = new LoginRequest();
        request.setEmail("test@example.com");
        request.setPassword("password");

        Customer customer = new Customer();
        customer.setEmail("test@example.com");
        customer.setPassword("encodedPassword");

        when(customerRepository.findByEmail(request.getEmail())).thenReturn(Optional.of(customer));
        when(passwordEncoder.matches(request.getPassword(), customer.getPassword())).thenReturn(true);

        String result = customerService.CustomerOrAdminLogin(request);

        assertEquals("Login successful!", result);
        verify(customerRepository, times(1)).findByEmail(request.getEmail());
        verify(passwordEncoder, times(1)).matches(request.getPassword(), customer.getPassword());
    }

    @Test
    void testCustomerOrAdminLogin_InvalidPassword() {

        LoginRequest request = new LoginRequest();
        request.setEmail("test@example.com");
        request.setPassword("wrongPassword");

        Customer customer = new Customer();
        customer.setEmail("test@example.com");
        customer.setPassword("encodedPassword");

        when(customerRepository.findByEmail(request.getEmail())).thenReturn(Optional.of(customer));
        when(passwordEncoder.matches(request.getPassword(), customer.getPassword())).thenReturn(false);

        assertThrows(InventoryAPIBadRequestException.class, () -> customerService.CustomerOrAdminLogin(request));
        verify(customerRepository, times(1)).findByEmail(request.getEmail());
        verify(passwordEncoder, times(1)).matches(request.getPassword(), customer.getPassword());
    }

    @Test
    void testGetCustomerProfile() {
        long customerId = 1L;
        Customer customer = new Customer();
        customer.setCustomerId(customerId);
        customer.setName("Test User");

        CustomerProfile customerProfile = new CustomerProfile();
        customerProfile.setName("Test User");

        when(customerRepository.findById(customerId)).thenReturn(Optional.of(customer));
        when(modelMapper.map(customer, CustomerProfile.class)).thenReturn(customerProfile);

        CustomerProfile result = customerService.getCustomerProfile(customerId);

        assertNotNull(result);
        assertEquals("Test User", result.getName());
        verify(customerRepository, times(1)).findById(customerId);
        verify(modelMapper, times(1)).map(customer, CustomerProfile.class);
    }

    @Test
    void testGetCustomerProfile_NotFound() {

        long customerId = 1L;
        when(customerRepository.findById(customerId)).thenReturn(Optional.empty());

        assertThrows(CustomerNotFoundException.class, () -> customerService.getCustomerProfile(customerId));
        verify(customerRepository, times(1)).findById(customerId);
    }

    @Test
    void testDeleteCustomerProfile() {

        long customerId = 1L;
        Customer customer = new Customer();
        customer.setCustomerId(customerId);

        when(customerRepository.findById(customerId)).thenReturn(Optional.of(customer));

        String result = customerService.deleteCustomerProfile(customerId);

        assertEquals("Customer deleted successfully", result);
        verify(customerRepository, times(1)).findById(customerId);
        verify(customerRepository, times(1)).delete(customer);
    }

    @Test
    void testDeleteCustomerProfile_NotFound() {

        long customerId = 1L;
        when(customerRepository.findById(customerId)).thenReturn(Optional.empty());

        assertThrows(CustomerNotFoundException.class, () -> customerService.deleteCustomerProfile(customerId));
        verify(customerRepository, times(1)).findById(customerId);
    }

    @Test
    void testGetAllCustomers() {

        Customer customer1 = new Customer();
        customer1.setName("Customer 1");

        Customer customer2 = new Customer();
        customer2.setName("Customer 2");

        List<Customer> customers = Arrays.asList(customer1, customer2);

        CustomerProfile profile1 = new CustomerProfile();
        profile1.setName("Customer 1");

        CustomerProfile profile2 = new CustomerProfile();
        profile2.setName("Customer 2");

        when(customerRepository.findAllCustomers()).thenReturn(customers);
        when(modelMapper.map(customer1, CustomerProfile.class)).thenReturn(profile1);
        when(modelMapper.map(customer2, CustomerProfile.class)).thenReturn(profile2);

        List<CustomerProfile> result = customerService.getAllCustomers();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Customer 1", result.get(0).getName());
        assertEquals("Customer 2", result.get(1).getName());
        verify(customerRepository, times(1)).findAllCustomers();
    }
}