package com.project.InventoryManagementSystem.ServicesTest;

import com.project.InventoryManagementSystem.DTO.OrderDto;
import com.project.InventoryManagementSystem.Entities.Customer;
import com.project.InventoryManagementSystem.Entities.Order;
import com.project.InventoryManagementSystem.Entities.Order.Status;
import com.project.InventoryManagementSystem.Exceptions.CustomerNotFoundException;
import com.project.InventoryManagementSystem.Exceptions.OrderNotFoundException;
import com.project.InventoryManagementSystem.Exceptions.ProductNotFoundException;
import com.project.InventoryManagementSystem.Repository.CustomerRepository;
import com.project.InventoryManagementSystem.Repository.OrderRepository;
import com.project.InventoryManagementSystem.Repository.ProductRepository;
import com.project.InventoryManagementSystem.Repository.StockRepository;
import com.project.InventoryManagementSystem.Service.Impl.OrderServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class OrderServiceImplTest {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private StockRepository stockRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private OrderServiceImpl orderService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testPlaceOrder_CustomerNotFound() {

        String email = "test@example.com";
        long productId = 1L;
        int quantity = 5;

        when(customerRepository.findByEmail(email)).thenReturn(Optional.empty());

        assertThrows(CustomerNotFoundException.class, () -> orderService.placeOrder(email, productId, quantity));
        verify(customerRepository, times(1)).findByEmail(email);
    }

    @Test
    void testPlaceOrder_ProductNotFound() {

        String email = "test@example.com";
        long productId = 1L;
        int quantity = 5;

        Customer customer = new Customer();
        customer.setEmail(email);

        when(customerRepository.findByEmail(email)).thenReturn(Optional.of(customer));
        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        assertThrows(ProductNotFoundException.class, () -> orderService.placeOrder(email, productId, quantity));
        verify(customerRepository, times(1)).findByEmail(email);
        verify(productRepository, times(1)).findById(productId);
    }

    @Test
    void testUpdateOrderStatus_OrderNotFound() {

        long orderId = 1L;
        Status status = Status.Shipped;

        when(orderRepository.findById(orderId)).thenReturn(Optional.empty());

        assertThrows(OrderNotFoundException.class, () -> orderService.updateOrderStatus(orderId, status));
        verify(orderRepository, times(1)).findById(orderId);
    }

    @Test
    void testGetAllOrders() {
        Order order1 = new Order();
        order1.setOrderId(1L);

        Order order2 = new Order();
        order2.setOrderId(2L);

        List<Order> orders = Arrays.asList(order1, order2);

        OrderDto orderDto1 = new OrderDto();
        orderDto1.setOrderId(1L);

        OrderDto orderDto2 = new OrderDto();
        orderDto2.setOrderId(2L);

        when(orderRepository.findAll()).thenReturn(orders);
        when(modelMapper.map(order1, OrderDto.class)).thenReturn(orderDto1);
        when(modelMapper.map(order2, OrderDto.class)).thenReturn(orderDto2);

        List<OrderDto> result = orderService.getAllOrders();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(1L, result.get(0).getOrderId());
        assertEquals(2L, result.get(1).getOrderId());
        verify(orderRepository, times(1)).findAll();
    }

    @Test
    void testGetOrderById_Success() {

        long orderId = 1L;
        String customerEmail = "test@example.com";

        Customer customer = new Customer();
        customer.setCustomerId(1L);
        customer.setEmail(customerEmail);

        Order order = new Order();
        order.setOrderId(orderId);
        order.setCustomer(customer);

        OrderDto orderDto = new OrderDto();
        orderDto.setOrderId(orderId);

        when(customerRepository.findByEmail(customerEmail)).thenReturn(Optional.of(customer));
        when(orderRepository.findById(orderId)).thenReturn(Optional.of(order));
        when(modelMapper.map(order, OrderDto.class)).thenReturn(orderDto);

        OrderDto result = orderService.getOrderById(orderId);

        assertNotNull(result);
        assertEquals(orderId, result.getOrderId());
        verify(customerRepository, times(1)).findByEmail(customerEmail);
        verify(orderRepository, times(1)).findById(orderId);
    }

    @Test
    void testGetOrderById_OrderNotFound() {
        long orderId = 1L;
        String customerEmail = "test@example.com";

        Customer customer = new Customer();
        customer.setCustomerId(1L);
        customer.setEmail(customerEmail);

        when(customerRepository.findByEmail(customerEmail)).thenReturn(Optional.of(customer));
        when(orderRepository.findById(orderId)).thenReturn(Optional.empty());

        assertThrows(OrderNotFoundException.class, () -> orderService.getOrderById(orderId));
        verify(customerRepository, times(1)).findByEmail(customerEmail);
        verify(orderRepository, times(1)).findById(orderId);
    }
}