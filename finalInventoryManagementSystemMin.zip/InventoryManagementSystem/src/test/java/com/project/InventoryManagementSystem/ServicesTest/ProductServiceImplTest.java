package com.project.InventoryManagementSystem.ServicesTest;

import com.project.InventoryManagementSystem.DTO.ProductDto;
import com.project.InventoryManagementSystem.Entities.Product;
import com.project.InventoryManagementSystem.Exceptions.ProductNotFoundException;
import com.project.InventoryManagementSystem.Repository.ProductRepository;
import com.project.InventoryManagementSystem.Repository.StockRepository;
import com.project.InventoryManagementSystem.Service.Impl.ProductServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ProductServiceImplTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private StockRepository stockRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private ProductServiceImpl productService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetProductById() {
        long productId = 1L;
        Product product = new Product();
        product.setProductId(productId);
        product.setName("Test Product");

        ProductDto productDto = new ProductDto();
        productDto.setName("Test Product");

        when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        when(modelMapper.map(product, ProductDto.class)).thenReturn(productDto);

        ProductDto result = productService.getProductById(productId);

        assertNotNull(result);
        assertEquals("Test Product", result.getName());
        verify(productRepository, times(1)).findById(productId);
    }

    @Test
    void testGetProductById_NotFound() {
        long productId = 1L;
        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        assertThrows(ProductNotFoundException.class, () -> productService.getProductById(productId));
        verify(productRepository, times(1)).findById(productId);
    }

    @Test
    void testGetAllProducts() {
        Product product1 = new Product();
        product1.setName("Product 1");

        Product product2 = new Product();
        product2.setName("Product 2");

        List<Product> products = Arrays.asList(product1, product2);

        ProductDto productDto1 = new ProductDto();
        productDto1.setName("Product 1");

        ProductDto productDto2 = new ProductDto();
        productDto2.setName("Product 2");

        when(productRepository.findAll()).thenReturn(products);
        when(modelMapper.map(product1, ProductDto.class)).thenReturn(productDto1);
        when(modelMapper.map(product2, ProductDto.class)).thenReturn(productDto2);

        List<ProductDto> result = productService.getAllProducts();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Product 1", result.get(0).getName());
        assertEquals("Product 2", result.get(1).getName());
        verify(productRepository, times(1)).findAll();
    }

    @Test
    void testDeleteProduct() {
        long productId = 1L;
        when(productRepository.existsById(productId)).thenReturn(true);

        productService.deleteProduct(productId);

        verify(productRepository, times(1)).existsById(productId);
        verify(productRepository, times(1)).deleteById(productId);
    }

    @Test
    void testDeleteProduct_NotFound() {

        long productId = 1L;
        when(productRepository.existsById(productId)).thenReturn(false);

        assertThrows(ProductNotFoundException.class, () -> productService.deleteProduct(productId));
        verify(productRepository, times(1)).existsById(productId);
    }
}