package com.project.InventoryManagementSystem.ServicesTest;

import com.project.InventoryManagementSystem.DTO.ReportDto;
import com.project.InventoryManagementSystem.Entities.Report;
import com.project.InventoryManagementSystem.Exceptions.IdNotFoundException;
import com.project.InventoryManagementSystem.Repository.ReportRepository;
import com.project.InventoryManagementSystem.Service.Impl.ReportServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ReportServiceImplTest {

    @Mock
    private ReportRepository reportRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private ReportServiceImpl reportService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateReport_Success() {

        ReportDto reportDto = new ReportDto();
        reportDto.setReportType(Report.ReportType.Order);
        reportDto.setStartDate(LocalDate.of(2023, 1, 1));
        reportDto.setEndDate(LocalDate.of(2023, 12, 31));

        Report report = new Report();
        report.setReportId(1L);

        when(modelMapper.map(reportDto, Report.class)).thenReturn(report);
        when(reportRepository.save(report)).thenReturn(report);

        String result = reportService.create(reportDto);

        assertEquals("Successfully created an entry with report ID : 1", result);
        verify(reportRepository, times(1)).save(report);
    }

    @Test
    void testGetReportById_Success() {

        long reportId = 1L;
        Report report = new Report();
        report.setReportId(reportId);

        ReportDto reportDto = new ReportDto();
        reportDto.setReportType(Report.ReportType.Order);

        when(reportRepository.findById(reportId)).thenReturn(Optional.of(report));
        when(modelMapper.map(report, ReportDto.class)).thenReturn(reportDto);

        ReportDto result = reportService.getReportById(reportId);

        assertNotNull(result);
        assertEquals(Report.ReportType.Order, result.getReportType());
        verify(reportRepository, times(1)).findById(reportId);
    }

    @Test
    void testGetReportById_NotFound() {
        long reportId = 1L;
        when(reportRepository.findById(reportId)).thenReturn(Optional.empty());

        assertThrows(IdNotFoundException.class, () -> reportService.getReportById(reportId));
        verify(reportRepository, times(1)).findById(reportId);
    }

    @Test
    void testGetAllReports() {

        Report report1 = new Report();
        report1.setReportId(1L);

        Report report2 = new Report();
        report2.setReportId(2L);

        List<Report> reports = Arrays.asList(report1, report2);

        ReportDto reportDto1 = new ReportDto();
        reportDto1.setReportType(Report.ReportType.Order);

        ReportDto reportDto2 = new ReportDto();
        reportDto2.setReportType(Report.ReportType.Inventory);

        when(reportRepository.findAll()).thenReturn(reports);
        when(modelMapper.map(report1, ReportDto.class)).thenReturn(reportDto1);
        when(modelMapper.map(report2, ReportDto.class)).thenReturn(reportDto2);

        List<ReportDto> result = reportService.findAllReports();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(Report.ReportType.Order, result.get(0).getReportType());
        assertEquals(Report.ReportType.Inventory, result.get(1).getReportType());
        verify(reportRepository, times(1)).findAll();
    }

    @Test
    void testDeleteReportById_Success() {
        long reportId = 1L;
        when(reportRepository.existsById(reportId)).thenReturn(true);

        reportService.deleteById(reportId);

        verify(reportRepository, times(1)).existsById(reportId);
        verify(reportRepository, times(1)).deleteById(reportId);
    }

    @Test
    void testDeleteReportById_NotFound() {

        long reportId = 1L;
        when(reportRepository.existsById(reportId)).thenReturn(false);

        assertThrows(IdNotFoundException.class, () -> reportService.deleteById(reportId));
        verify(reportRepository, times(1)).existsById(reportId);
    }
}