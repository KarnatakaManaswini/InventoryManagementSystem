package com.project.InventoryManagementSystem.ServicesTest;

import com.project.InventoryManagementSystem.DTO.NotificationDto;
import com.project.InventoryManagementSystem.Entities.Notification;
import com.project.InventoryManagementSystem.Repository.NotificationRepository;
import com.project.InventoryManagementSystem.Service.Impl.NotificationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class NotificationServiceImplTest {

    @Mock
    private NotificationRepository notificationRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private NotificationServiceImpl notificationService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllNotifications() {
        Notification notification1 = new Notification();
        notification1.setId(1L);
        notification1.setMessage("Notification 1");

        Notification notification2 = new Notification();
        notification2.setId(2L);
        notification2.setMessage("Notification 2");

        List<Notification> notifications = Arrays.asList(notification1, notification2);

        NotificationDto notificationDto1 = new NotificationDto();
        notificationDto1.setId(1L);
        notificationDto1.setMessage("Notification 1");

        NotificationDto notificationDto2 = new NotificationDto();
        notificationDto2.setId(2L);
        notificationDto2.setMessage("Notification 2");

        when(notificationRepository.findAll()).thenReturn(notifications);
        when(modelMapper.map(notification1, NotificationDto.class)).thenReturn(notificationDto1);
        when(modelMapper.map(notification2, NotificationDto.class)).thenReturn(notificationDto2);

        List<NotificationDto> result = notificationService.getAllNotifications();

        assertEquals(2, result.size());
        assertEquals("Notification 1", result.get(0).getMessage());
        assertEquals("Notification 2", result.get(1).getMessage());

        verify(notificationRepository, times(1)).findAll();
        verify(modelMapper, times(1)).map(notification1, NotificationDto.class);
        verify(modelMapper, times(1)).map(notification2, NotificationDto.class);
    }
}